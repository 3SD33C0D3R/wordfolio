import JSZip from 'jszip';

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function parseDocxRun(rEl: Element): string {
  const rPr = rEl.getElementsByTagName('w:rPr')[0];
  const texts = Array.from(rEl.getElementsByTagName('w:t'));
  const tabs = rEl.getElementsByTagName('w:tab').length;
  const brs = rEl.getElementsByTagName('w:br').length;

  let content = '';
  for (let i = 0; i < tabs; i++) content += '&nbsp;&nbsp;&nbsp;&nbsp;';
  for (const t of texts) {
    content += escapeHtml(t.textContent || '');
  }
  for (let i = 0; i < brs; i++) content += '<br>';

  if (!content) return '';

  if (rPr) {
    const isBold = rPr.getElementsByTagName('w:b').length > 0;
    const isItalic = rPr.getElementsByTagName('w:i').length > 0;
    const isUnderline = rPr.getElementsByTagName('w:u').length > 0;
    const isStrike = rPr.getElementsByTagName('w:strike').length > 0;
    const colorEl = rPr.getElementsByTagName('w:color')[0];
    const szEl = rPr.getElementsByTagName('w:sz')[0];

    const styles: string[] = [];
    if (colorEl) {
      const val = colorEl.getAttribute('w:val');
      if (val && val !== 'auto' && /^[0-9A-Fa-f]{6}$/.test(val)) {
        styles.push(`color: #${val}`);
      }
    }
    if (szEl) {
      const halfPt = parseInt(szEl.getAttribute('w:val') || '', 10);
      if (!Number.isNaN(halfPt) && halfPt > 0) {
        styles.push(`font-size: ${halfPt / 2}pt`);
      }
    }

    if (styles.length > 0) {
      content = `<span style="${styles.join('; ')}">${content}</span>`;
    }
    if (isStrike) content = `<s>${content}</s>`;
    if (isUnderline) content = `<u>${content}</u>`;
    if (isItalic) content = `<em>${content}</em>`;
    if (isBold) content = `<strong>${content}</strong>`;
  }

  return content;
}

function parseDocxParagraph(pEl: Element): { html: string; isList: boolean } {
  const pPr = pEl.getElementsByTagName('w:pPr')[0];
  let tag = 'p';
  let alignStyle = '';
  let isList = false;

  if (pPr) {
    const pStyle = pPr.getElementsByTagName('w:pStyle')[0]?.getAttribute('w:val') || '';
    if (/heading1|title/i.test(pStyle)) tag = 'h1';
    else if (/heading2|subtitle/i.test(pStyle)) tag = 'h2';
    else if (/heading3/i.test(pStyle)) tag = 'h3';

    const jc = pPr.getElementsByTagName('w:jc')[0]?.getAttribute('w:val');
    if (jc === 'center') alignStyle = ' style="text-align: center;"';
    else if (jc === 'right') alignStyle = ' style="text-align: right;"';
    else if (jc === 'both') alignStyle = ' style="text-align: justify;"';

    if (pPr.getElementsByTagName('w:numPr').length > 0) {
      isList = true;
    }
  }

  const runs = Array.from(pEl.childNodes)
    .filter((n): n is Element => n.nodeType === 1 && n.nodeName === 'w:r')
    .map(parseDocxRun)
    .join('');

  if (isList) {
    return { html: `<li>${runs || '<br>'}</li>`, isList: true };
  }

  return { html: `<${tag}${alignStyle}>${runs || '<br>'}</${tag}>`, isList: false };
}

export async function importDocumentFile(
  file: File
): Promise<{ title: string; html: string }> {
  const title = file.name.replace(/\.[^.]+$/, '') || 'Imported Document';
  const ext = file.name.split('.').pop()?.toLowerCase();

  if (ext === 'docx') {
    const buffer = await file.arrayBuffer();
    const zip = await JSZip.loadAsync(buffer);
    const docXmlFile = zip.file('word/document.xml');
    if (!docXmlFile) {
      throw new Error('Invalid .docx archive: missing word/document.xml');
    }
    const xmlStr = await docXmlFile.async('string');
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlStr, 'application/xml');
    const body = xmlDoc.getElementsByTagName('w:body')[0];
    if (!body) {
      return { title, html: '<p><br></p>' };
    }

    const parts: string[] = [];
    let openList = false;

    for (let i = 0; i < body.childNodes.length; i++) {
      const node = body.childNodes[i];
      if (node.nodeType !== 1) continue;
      const el = node as Element;

      if (el.nodeName === 'w:p') {
        const parsed = parseDocxParagraph(el);
        if (parsed.isList && !openList) {
          parts.push('<ul>');
          openList = true;
        } else if (!parsed.isList && openList) {
          parts.push('</ul>');
          openList = false;
        }
        parts.push(parsed.html);
      } else if (el.nodeName === 'w:tbl') {
        if (openList) {
          parts.push('</ul>');
          openList = false;
        }
        const rows = Array.from(el.getElementsByTagName('w:tr'));
        const rowsHtml = rows
          .map((tr, rIdx) => {
            const cells = Array.from(tr.getElementsByTagName('w:tc'));
            const cellTag = rIdx === 0 ? 'th' : 'td';
            const cellsHtml = cells
              .map((tc) => {
                const pList = Array.from(tc.getElementsByTagName('w:p'));
                const inner = pList
                  .map((p) => {
                    const runs = Array.from(p.childNodes)
                      .filter((n): n is Element => n.nodeType === 1 && n.nodeName === 'w:r')
                      .map(parseDocxRun)
                      .join('');
                    return runs;
                  })
                  .join('<br>');
                return `<${cellTag}>${inner || '&nbsp;'}</${cellTag}>`;
              })
              .join('');
            return `<tr>${cellsHtml}</tr>`;
          })
          .join('');
        parts.push(`<table><tbody>${rowsHtml}</tbody></table>`);
      }
    }

    if (openList) parts.push('</ul>');
    return { title, html: parts.join('\n') || '<p><br></p>' };
  }

  const text = await file.text();
  if (ext === 'html' || ext === 'htm') {
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'text/html');
    return { title, html: doc.body.innerHTML || '<p><br></p>' };
  }

  // Plain text (.txt, .md)
  const paragraphs = text
    .split(/\r?\n\r?\n/)
    .map((block) => `<p>${escapeHtml(block).replace(/\r?\n/g, '<br>') || '<br>'}</p>`)
    .join('\n');
  return { title, html: paragraphs || '<p><br></p>' };
}
