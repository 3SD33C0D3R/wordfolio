import {
  COMMON_MISSPELLINGS,
  getSpellingSuggestions,
  isKnownWord,
} from '../data/dictionary';
import {
  DocumentStats,
  HeadingNode,
  IssueKind,
  OverlayRect,
  ProofingIssue,
} from '../types/document';

interface TextSegment {
  node: Text;
  start: number;
  end: number;
}

const BLOCK_TAGS = new Set([
  'P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
  'LI', 'BLOCKQUOTE', 'TD', 'TH', 'PRE',
]);

function collectBlockTextMaps(root: HTMLElement): Array<{
  text: string;
  segments: TextSegment[];
}> {
  const blocks: Array<{ text: string; segments: TextSegment[] }> = [];
  let currentSegments: TextSegment[] = [];
  let currentText = '';

  const flush = () => {
    if (currentSegments.length > 0 && currentText.length > 0) {
      blocks.push({ text: currentText, segments: currentSegments });
    }
    currentSegments = [];
    currentText = '';
  };

  const walk = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const val = node.nodeValue || '';
      if (val.length > 0) {
        const start = currentText.length;
        currentText += val;
        currentSegments.push({
          node: node as Text,
          start,
          end: currentText.length,
        });
      }
      return;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      if (el.classList.contains('folio-page-break')) {
        flush();
        return;
      }
      if (el.tagName === 'BR') {
        flush();
        return;
      }
      const isBlock = el !== root && BLOCK_TAGS.has(el.tagName);
      if (isBlock) flush();

      for (let i = 0; i < el.childNodes.length; i++) {
        walk(el.childNodes[i]);
      }

      if (isBlock) flush();
    }
  };

  walk(root);
  flush();
  return blocks;
}

function buildRange(
  segments: TextSegment[],
  startOffset: number,
  endOffset: number
): Range | null {
  let startNode: Text | null = null;
  let startNodeOffset = 0;
  let endNode: Text | null = null;
  let endNodeOffset = 0;

  for (const seg of segments) {
    if (!startNode && startOffset >= seg.start && startOffset <= seg.end) {
      startNode = seg.node;
      startNodeOffset = startOffset - seg.start;
    }
    if (endOffset >= seg.start && endOffset <= seg.end) {
      endNode = seg.node;
      endNodeOffset = endOffset - seg.start;
      break;
    }
  }

  if (!startNode || !endNode) return null;
  try {
    const range = document.createRange();
    range.setStart(startNode, startNodeOffset);
    range.setEnd(endNode, endNodeOffset);
    return range;
  } catch {
    return null;
  }
}

function computeRects(
  range: Range,
  containerRect: DOMRect,
  zoomScale: number
): OverlayRect[] {
  const clientRects = Array.from(range.getClientRects());
  return clientRects
    .filter((r) => r.width > 0 && r.height > 0)
    .map((r) => ({
      left: (r.left - containerRect.left) / zoomScale,
      top: (r.top - containerRect.top) / zoomScale,
      width: r.width / zoomScale,
      height: r.height / zoomScale,
    }));
}

function makeSnippet(text: string, start: number, end: number): string {
  const from = Math.max(0, start - 22);
  const to = Math.min(text.length, end + 22);
  const prefix = from > 0 ? '…' : '';
  const suffix = to < text.length ? '…' : '';
  return prefix + text.slice(from, to).trim() + suffix;
}

interface GrammarPattern {
  regex: RegExp;
  kind: IssueKind;
  message: string;
  explanation: string;
  getReplacements: (match: RegExpExecArray) => string[];
}

const GRAMMAR_RULES: GrammarPattern[] = [
  {
    regex: /\b([A-Za-z]+)\s+\1\b/gi,
    kind: 'grammar',
    message: 'Repeated word',
    explanation: 'This word appears twice in a row. Remove the duplicate.',
    getReplacements: (m) => [m[1]],
  },
  {
    regex: /\b(could|should|would|might|must)\s+of\b/gi,
    kind: 'grammar',
    message: 'Verb phrase error',
    explanation: 'Use "have" instead of "of" after modal verbs.',
    getReplacements: (m) => [`${m[1]} have`],
  },
  {
    regex: /\b(he|she|it)\s+don't\b/gi,
    kind: 'grammar',
    message: 'Subject-verb agreement',
    explanation: 'Third-person singular subjects pair with "doesn\'t".',
    getReplacements: (m) => [`${m[1]} doesn't`],
  },
  {
    regex: /\b(they|we|you)\s+was\b/gi,
    kind: 'grammar',
    message: 'Subject-verb agreement',
    explanation: 'Plural/second-person subjects require "were" instead of "was".',
    getReplacements: (m) => [`${m[1]} were`],
  },
  {
    regex: /\bthere\s+is\s+(many|several|numerous|multiple)\b/gi,
    kind: 'grammar',
    message: 'Subject-verb agreement',
    explanation: 'Plural quantifiers pair with "there are".',
    getReplacements: (m) => [`there are ${m[1]}`],
  },
  {
    regex: /\btheir\s+(is|are|was|were)\b/gi,
    kind: 'grammar',
    message: 'Confused homophone ("their" vs. "there")',
    explanation: 'Use "there" to introduce existence rather than possessive "their".',
    getReplacements: (m) => {
      const cap = m[0][0] === 'T' ? 'There' : 'there';
      return [`${cap} ${m[1]}`];
    },
  },
  {
    regex: /\byour\s+welcome\b/gi,
    kind: 'grammar',
    message: 'Contraction error ("your" vs. "you\'re")',
    explanation: 'Use "you\'re" (short for "you are") in this expression.',
    getReplacements: (m) => [m[0][0] === 'Y' ? "You're welcome" : "you're welcome"],
  },
  {
    regex: /\b(more|better|less|greater|rather|other|higher|lower|faster|slower)\s+then\b/gi,
    kind: 'grammar',
    message: 'Comparison word ("then" vs. "than")',
    explanation: 'Use "than" for comparisons; "then" refers to time or sequence.',
    getReplacements: (m) => [`${m[1]} than`],
  },
  {
    regex: /\ba\s+(apple|orange|hour|honest|honor|issue|item|idea|example|essay|executive|email|office|error|update|overview|approach|analysis|outcome|elephant|umbrella)\b/gi,
    kind: 'grammar',
    message: 'Article mismatch ("a" vs. "an")',
    explanation: 'Use "an" before words beginning with a vowel sound.',
    getReplacements: (m) => [`${m[0][0] === 'A' ? 'An' : 'an'} ${m[1]}`],
  },
  {
    regex: /\ban\s+(university|user|unit|european|unique|uniform|union|one|house|book|report|project|company|student|system|plan|table|document)\b/gi,
    kind: 'grammar',
    message: 'Article mismatch ("an" vs. "a")',
    explanation: 'Use "a" before words beginning with a consonant sound.',
    getReplacements: (m) => [`${m[0][0] === 'A' ? 'A' : 'a'} ${m[1]}`],
  },
  {
    regex: /\birregardless\b/gi,
    kind: 'grammar',
    message: 'Nonstandard word',
    explanation: 'Use "regardless" in formal and academic writing.',
    getReplacements: (m) => [m[0][0] === 'I' ? 'Regardless' : 'regardless'],
  },
  {
    regex: /\bsuppose\s+to\b/gi,
    kind: 'grammar',
    message: 'Missing past participle',
    explanation: 'The idiom requires "supposed to".',
    getReplacements: (m) => [m[0][0] === 'S' ? 'Supposed to' : 'supposed to'],
  },
  {
    regex: /\bi\b/g,
    kind: 'grammar',
    message: 'Capitalize pronoun "I"',
    explanation: 'The first-person pronoun "I" is always capitalized.',
    getReplacements: () => ['I'],
  },
  {
    regex: /([.!?])\s+([a-z][a-zA-Z']*)/g,
    kind: 'grammar',
    message: 'Sentence capitalization',
    explanation: 'Begin a new sentence with an uppercase letter.',
    getReplacements: (m) => [
      `${m[1]} ${m[2].charAt(0).toUpperCase()}${m[2].slice(1)}`,
    ],
  },
  {
    regex: / {2,}/g,
    kind: 'grammar',
    message: 'Extra spacing',
    explanation: 'Multiple consecutive spaces found; use a single space.',
    getReplacements: () => [' '],
  },
  {
    regex: /\bin order to\b/gi,
    kind: 'style',
    message: 'Wordy phrase',
    explanation: 'Consider simplifying "in order to" to "to" for clearer prose.',
    getReplacements: (m) => [m[0][0] === 'I' ? 'To' : 'to'],
  },
  {
    regex: /\bdue to the fact that\b/gi,
    kind: 'style',
    message: 'Wordy phrase',
    explanation: 'Consider replacing with "because" for stronger conciseness.',
    getReplacements: (m) => [m[0][0] === 'D' ? 'Because' : 'because'],
  },
  {
    regex: /\bat this point in time\b/gi,
    kind: 'style',
    message: 'Wordy phrase',
    explanation: 'Consider replacing with "now" or "currently".',
    getReplacements: (m) => [
      m[0][0] === 'A' ? 'Currently' : 'currently',
      m[0][0] === 'A' ? 'Now' : 'now',
    ],
  },
];

export function analyzeDocumentProofing(
  root: HTMLElement,
  customDictionary: Set<string>,
  ignoredTokens: Set<string>,
  zoomScale: number,
  options: { checkSpelling: boolean; checkGrammar: boolean; checkStyle: boolean }
): ProofingIssue[] {
  const blocks = collectBlockTextMaps(root);
  const containerRect = root.getBoundingClientRect();
  const issues: ProofingIssue[] = [];
  let seq = 0;

  for (const block of blocks) {
    const { text, segments } = block;
    const occupiedSpans: Array<[number, number]> = [];

    // 1. Grammar & style passes first
    for (const rule of GRAMMAR_RULES) {
      if (rule.kind === 'grammar' && !options.checkGrammar) continue;
      if (rule.kind === 'style' && !options.checkStyle) continue;

      rule.regex.lastIndex = 0;
      let match: RegExpExecArray | null;
      while ((match = rule.regex.exec(text)) !== null) {
        const start = match.index;
        const end = start + match[0].length;
        const tokenKey = `${rule.kind}:${match[0].toLowerCase()}:${start}`;
        if (ignoredTokens.has(match[0].toLowerCase()) || ignoredTokens.has(tokenKey)) {
          continue;
        }
        // Skip "i" if it's part of roman numeral or after dot like e.g. i.e.
        if (match[0] === 'i') {
          const prevChar = text[start - 1];
          const nextChar = text[end];
          if (prevChar === '.' || nextChar === '.' || nextChar === ')') continue;
        }

        const range = buildRange(segments, start, end);
        if (!range) continue;

        occupiedSpans.push([start, end]);
        issues.push({
          id: `issue-${seq++}`,
          kind: rule.kind,
          wordOrPhrase: match[0],
          contextSnippet: makeSnippet(text, start, end),
          message: rule.message,
          explanation: rule.explanation,
          replacements: rule.getReplacements(match),
          startOffset: start,
          endOffset: end,
          range,
          rects: computeRects(range, containerRect, zoomScale),
        });
      }
    }

    // 2. Spelling pass
    if (options.checkSpelling) {
      const wordRegex = /\b[A-Za-z]+(?:['’-][A-Za-z]+)*\b/g;
      let wMatch: RegExpExecArray | null;
      while ((wMatch = wordRegex.exec(text)) !== null) {
        const word = wMatch[0];
        const start = wMatch.index;
        const end = start + word.length;

        if (word.length <= 1) continue;
        // Skip URLs or emails
        const before = text.slice(Math.max(0, start - 8), start);
        const after = text.slice(end, end + 6);
        if (before.includes('@') || before.includes('http') || after.startsWith('@') || after.startsWith('.com')) {
          continue;
        }
        // Skip ALL-CAPS acronyms <= 5 chars (e.g., NATO, NASA, FY26, EBITDA)
        if (word === word.toUpperCase() && word.length <= 6) continue;

        if (ignoredTokens.has(word.toLowerCase())) continue;

        // Skip capitalized proper nouns mid-sentence unless they are in COMMON_MISSPELLINGS
        const isCapitalized = word[0] === word[0].toUpperCase() && word.slice(1) === word.slice(1).toLowerCase();
        const isAtSentenceStart = start === 0 || /[.!?\n]\s*$/.test(text.slice(0, start));
        const isKnownMisspelling = Boolean(COMMON_MISSPELLINGS[word.toLowerCase()]);

        if (isCapitalized && !isAtSentenceStart && !isKnownMisspelling) {
          continue;
        }

        if (!isKnownWord(word, customDictionary)) {
          // Avoid overlapping an already flagged grammar issue
          const overlaps = occupiedSpans.some(([s, e]) => start < e && end > s);
          if (overlaps) continue;

          const range = buildRange(segments, start, end);
          if (!range) continue;

          const suggestions = getSpellingSuggestions(word, 4);
          issues.push({
            id: `issue-${seq++}`,
            kind: 'spelling',
            wordOrPhrase: word,
            contextSnippet: makeSnippet(text, start, end),
            message: 'Spelling',
            explanation:
              suggestions.length > 0
                ? `"${word}" may be misspelled. Select a suggested correction below.`
                : `"${word}" is not in the standard dictionary.`,
            replacements: suggestions,
            startOffset: start,
            endOffset: end,
            range,
            rects: computeRects(range, containerRect, zoomScale),
          });
        }
      }
    }
  }

  return issues;
}

export function applyIssueReplacement(issue: ProofingIssue, replacement: string): boolean {
  try {
    const range = issue.range;
    range.deleteContents();
    const textNode = document.createTextNode(replacement);
    range.insertNode(textNode);
    // Collapse selection after inserted text
    const sel = window.getSelection();
    if (sel) {
      const nextRange = document.createRange();
      nextRange.setStartAfter(textNode);
      nextRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(nextRange);
    }
    return true;
  } catch {
    return false;
  }
}

function countSyllables(word: string): number {
  const clean = word.toLowerCase().replace(/[^a-z]/g, '');
  if (clean.length <= 3) return 1;
  const trimmed = clean.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, '');
  const matches = trimmed.match(/[aeiouy]{1,2}/g);
  return matches ? Math.max(1, matches.length) : 1;
}

export function computeDocumentStats(root: HTMLElement | null): DocumentStats {
  if (!root) {
    return {
      words: 0,
      characters: 0,
      charactersNoSpaces: 0,
      sentences: 0,
      paragraphs: 0,
      readingTimeMinutes: 0,
      gradeLevel: 0,
      estimatedPages: 1,
    };
  }

  const rawText = root.innerText || '';
  const trimmed = rawText.trim();
  if (!trimmed) {
    return {
      words: 0,
      characters: 0,
      charactersNoSpaces: 0,
      sentences: 0,
      paragraphs: 0,
      readingTimeMinutes: 0,
      gradeLevel: 0,
      estimatedPages: 1,
    };
  }

  const wordMatches = trimmed.match(/\b[\w’'-]+\b/g) || [];
  const words = wordMatches.length;
  const characters = trimmed.length;
  const charactersNoSpaces = trimmed.replace(/\s+/g, '').length;
  const sentences = Math.max(1, (trimmed.match(/[.!?]+(?:\s|$)/g) || []).length);
  const paragraphs = trimmed
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean).length;

  let totalSyllables = 0;
  for (const w of wordMatches) {
    totalSyllables += countSyllables(w);
  }

  const gradeRaw =
    words > 5
      ? 0.39 * (words / sentences) + 11.8 * (totalSyllables / words) - 15.59
      : 0;
  const gradeLevel = Math.max(1, Math.min(18, Math.round(gradeRaw * 10) / 10));

  const readingTimeMinutes = words === 0 ? 0 : Math.max(1, Math.ceil(words / 225));
  const pageBreakCount = root.querySelectorAll('.folio-page-break').length;
  const estimatedPages = Math.max(1 + pageBreakCount, Math.ceil(words / 420) || 1);

  return {
    words,
    characters,
    charactersNoSpaces,
    sentences,
    paragraphs,
    readingTimeMinutes,
    gradeLevel,
    estimatedPages,
  };
}

export function extractDocumentHeadings(root: HTMLElement | null): HeadingNode[] {
  if (!root) return [];
  const headings = Array.from(root.querySelectorAll('h1, h2, h3'));
  return headings
    .map((el, index) => {
      const text = (el.textContent || '').trim();
      const level = (el.tagName === 'H1' ? 1 : el.tagName === 'H2' ? 2 : 3) as 1 | 2 | 3;
      return {
        id: `heading-${index}`,
        level,
        text: text || '(Untitled heading)',
        elementIndex: index,
      };
    })
    .filter((h) => h.text !== '(Untitled heading)');
}
