import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  Header,
  HeadingLevel,
  Packer,
  PageBreak,
  PageOrientation,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
  convertInchesToTwip,
} from 'docx';
import { PageSettings } from '../types/document';

interface InlineStyleState {
  bold?: boolean;
  italics?: boolean;
  underline?: boolean;
  strike?: boolean;
  subScript?: boolean;
  superScript?: boolean;
  color?: string;
  highlight?: string;
  font?: string;
  sizeHalfPt?: number;
}

function rgbToHex(colorStr: string | undefined): string | undefined {
  if (!colorStr) return undefined;
  const trimmed = colorStr.trim();
  if (trimmed.startsWith('#')) {
    const hex = trimmed.slice(1);
    if (hex.length === 3) {
      return hex
        .split('')
        .map((c) => c + c)
        .join('')
        .toUpperCase();
    }
    if (hex.length === 6) return hex.toUpperCase();
  }
  const match = trimmed.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (match) {
    const toHex = (n: string) =>
      Math.max(0, Math.min(255, parseInt(n, 10)))
        .toString(16)
        .padStart(2, '0');
    return `${toHex(match[1])}${toHex(match[2])}${toHex(match[3])}`.toUpperCase();
  }
  return undefined;
}

function mapHighlightColor(
  bgColor: string | undefined
):
  | 'yellow'
  | 'green'
  | 'cyan'
  | 'magenta'
  | 'blue'
  | 'red'
  | 'darkBlue'
  | 'lightGray'
  | undefined {
  const hex = rgbToHex(bgColor);
  if (!hex) return undefined;
  if (hex === 'FEF08A' || hex === 'FDE047' || hex === 'FFFF00') return 'yellow';
  if (hex === 'BBF7D0' || hex === '86EFAC' || hex === '00FF00') return 'green';
  if (hex === 'BAE6FD' || hex === 'A5F3FC' || hex === '00FFFF') return 'cyan';
  if (hex === 'FBCFE8' || hex === 'F5D0FE' || hex === 'FF00FF') return 'magenta';
  if (hex === 'FECACA' || hex === 'FCA5A5') return 'red';
  if (hex === 'E2E8F0' || hex === 'F1F5F9') return 'lightGray';
  return 'yellow';
}

function parseFontSizeToHalfPt(fontSizeStr: string | undefined): number | undefined {
  if (!fontSizeStr) return undefined;
  const trimmed = fontSizeStr.trim().toLowerCase();
  if (trimmed.endsWith('pt')) {
    const pt = parseFloat(trimmed);
    if (!Number.isNaN(pt)) return Math.round(pt * 2);
  }
  if (trimmed.endsWith('px')) {
    const px = parseFloat(trimmed);
    if (!Number.isNaN(px)) return Math.round(px * 0.75 * 2);
  }
  return undefined;
}

function cleanFontName(fontFamily: string | undefined): string | undefined {
  if (!fontFamily) return undefined;
  const first = fontFamily.split(',')[0]?.replace(/['"]/g, '').trim();
  return first || undefined;
}

function mapAlignment(
  alignStr: string | undefined
): (typeof AlignmentType)[keyof typeof AlignmentType] | undefined {
  if (!alignStr) return undefined;
  switch (alignStr.toLowerCase()) {
    case 'center':
      return AlignmentType.CENTER;
    case 'right':
    case 'end':
      return AlignmentType.RIGHT;
    case 'justify':
      return AlignmentType.JUSTIFIED;
    case 'left':
    case 'start':
      return AlignmentType.LEFT;
    default:
      return undefined;
  }
}

function extractTextRuns(
  node: Node,
  inherited: InlineStyleState,
  defaultFont: string,
  defaultHalfPt: number
): TextRun[] {
  const runs: TextRun[] = [];

  if (node.nodeType === Node.TEXT_NODE) {
    const text = node.nodeValue || '';
    if (text.length > 0) {
      runs.push(
        new TextRun({
          text,
          bold: inherited.bold,
          italics: inherited.italics,
          underline: inherited.underline ? { type: UnderlineType.SINGLE } : undefined,
          strike: inherited.strike,
          subScript: inherited.subScript,
          superScript: inherited.superScript,
          color: inherited.color,
          highlight: mapHighlightColor(inherited.highlight),
          font: inherited.font || defaultFont,
          size: inherited.sizeHalfPt || defaultHalfPt,
        })
      );
    }
    return runs;
  }

  if (node.nodeType !== Node.ELEMENT_NODE) return runs;

  const el = node as HTMLElement;
  const tag = el.tagName;

  if (tag === 'BR') {
    runs.push(new TextRun({ text: '', break: 1 }));
    return runs;
  }

  const nextStyle: InlineStyleState = { ...inherited };

  if (tag === 'B' || tag === 'STRONG') nextStyle.bold = true;
  if (tag === 'I' || tag === 'EM') nextStyle.italics = true;
  if (tag === 'U') nextStyle.underline = true;
  if (tag === 'S' || tag === 'STRIKE' || tag === 'DEL') nextStyle.strike = true;
  if (tag === 'SUB') nextStyle.subScript = true;
  if (tag === 'SUP') nextStyle.superScript = true;

  if (tag === 'FONT') {
    const face = el.getAttribute('face');
    const color = el.getAttribute('color');
    const sizeAttr = el.getAttribute('size');
    if (face) nextStyle.font = cleanFontName(face);
    if (color) nextStyle.color = rgbToHex(color);
    if (sizeAttr) {
      const sizeMap: Record<string, number> = {
        '1': 16,
        '2': 20,
        '3': 24,
        '4': 28,
        '5': 36,
        '6': 48,
        '7': 72,
      };
      if (sizeMap[sizeAttr]) nextStyle.sizeHalfPt = sizeMap[sizeAttr];
    }
  }

  const inline = el.style;
  if (inline) {
    if (inline.fontWeight === 'bold' || Number(inline.fontWeight) >= 600) {
      nextStyle.bold = true;
    }
    if (inline.fontStyle === 'italic') nextStyle.italics = true;
    if (inline.textDecoration?.includes('underline')) nextStyle.underline = true;
    if (inline.textDecoration?.includes('line-through')) nextStyle.strike = true;
    if (inline.color) nextStyle.color = rgbToHex(inline.color) || nextStyle.color;
    if (inline.backgroundColor && inline.backgroundColor !== 'transparent') {
      nextStyle.highlight = inline.backgroundColor;
    }
    if (inline.fontFamily) nextStyle.font = cleanFontName(inline.fontFamily);
    const halfPt = parseFontSizeToHalfPt(inline.fontSize);
    if (halfPt) nextStyle.sizeHalfPt = halfPt;
  }

  for (let i = 0; i < el.childNodes.length; i++) {
    runs.push(...extractTextRuns(el.childNodes[i], nextStyle, defaultFont, defaultHalfPt));
  }
  return runs;
}

function getPaperDimensionsTwip(settings: PageSettings): { width: number; height: number } {
  const sizes = {
    letter: { w: 8.5, h: 11 },
    a4: { w: 8.27, h: 11.69 },
    legal: { w: 8.5, h: 14 },
  };
  const dim = sizes[settings.paperSize];
  const isLandscape = settings.orientation === 'landscape';
  const w = isLandscape ? dim.h : dim.w;
  const h = isLandscape ? dim.w : dim.h;
  return {
    width: convertInchesToTwip(w),
    height: convertInchesToTwip(h),
  };
}

export async function exportToDocx(
  title: string,
  htmlContent: string,
  settings: PageSettings
): Promise<void> {
  const parser = new DOMParser();
  const parsed = parser.parseFromString(`<div>${htmlContent}</div>`, 'text/html');
  const root = parsed.body.firstElementChild as HTMLElement;

  const defaultFont = cleanFontName(settings.defaultFontFamily) || 'Georgia';
  const defaultHalfPt = Math.round(settings.defaultFontSizePt * 2);
  const lineSpacing240 = Math.round(settings.lineHeight * 240);
  const afterSpacingTwip = Math.round(settings.paragraphSpacingAfter * 200);

  const docChildren: Array<Paragraph | Table> = [];

  const pushParagraphFromElement = (
    el: HTMLElement,
    overrides?: {
      heading?: (typeof HeadingLevel)[keyof typeof HeadingLevel];
      bulletLevel?: number;
      numbering?: { reference: string; level: number };
      isQuote?: boolean;
      fontSizeHalfPt?: number;
      bold?: boolean;
      italics?: boolean;
    }
  ) => {
    const alignment = mapAlignment(el.style.textAlign || el.getAttribute('align') || undefined);
    const runs = extractTextRuns(
      el,
      {
        bold: overrides?.bold,
        italics: overrides?.italics,
        sizeHalfPt: overrides?.fontSizeHalfPt,
      },
      defaultFont,
      defaultHalfPt
    );

    docChildren.push(
      new Paragraph({
        heading: overrides?.heading,
        alignment,
        bullet: overrides?.bulletLevel !== undefined ? { level: overrides.bulletLevel } : undefined,
        numbering: overrides?.numbering,
        indent: overrides?.isQuote ? { left: convertInchesToTwip(0.5) } : undefined,
        spacing: {
          line: lineSpacing240,
          after: afterSpacingTwip,
        },
        children: runs.length > 0 ? runs : [new TextRun('')],
      })
    );
  };

  const processNode = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const txt = (node.nodeValue || '').trim();
      if (txt) {
        docChildren.push(
          new Paragraph({
            spacing: { line: lineSpacing240, after: afterSpacingTwip },
            children: [
              new TextRun({
                text: txt,
                font: defaultFont,
                size: defaultHalfPt,
              }),
            ],
          })
        );
      }
      return;
    }

    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    const tag = el.tagName;

    if (el.classList.contains('folio-page-break')) {
      docChildren.push(new Paragraph({ children: [new PageBreak()] }));
      return;
    }

    if (tag === 'H1') {
      pushParagraphFromElement(el, {
        heading: HeadingLevel.HEADING_1,
        fontSizeHalfPt: Math.round(defaultHalfPt * 1.65),
        bold: true,
      });
      return;
    }
    if (tag === 'H2') {
      pushParagraphFromElement(el, {
        heading: HeadingLevel.HEADING_2,
        fontSizeHalfPt: Math.round(defaultHalfPt * 1.35),
        bold: true,
      });
      return;
    }
    if (tag === 'H3') {
      pushParagraphFromElement(el, {
        heading: HeadingLevel.HEADING_3,
        fontSizeHalfPt: Math.round(defaultHalfPt * 1.15),
        bold: true,
      });
      return;
    }
    if (tag === 'BLOCKQUOTE') {
      pushParagraphFromElement(el, { isQuote: true, italics: true });
      return;
    }
    if (tag === 'HR') {
      docChildren.push(
        new Paragraph({
          border: {
            bottom: {
              color: 'CBD5E1',
              space: 4,
              style: BorderStyle.SINGLE,
              size: 6,
            },
          },
          spacing: { after: 200 },
          children: [],
        })
      );
      return;
    }
    if (tag === 'UL') {
      Array.from(el.children).forEach((li) => {
        if (li.tagName === 'LI') {
          pushParagraphFromElement(li as HTMLElement, { bulletLevel: 0 });
        }
      });
      return;
    }
    if (tag === 'OL') {
      Array.from(el.children).forEach((li) => {
        if (li.tagName === 'LI') {
          pushParagraphFromElement(li as HTMLElement, {
            numbering: { reference: 'folio-numbered-list', level: 0 },
          });
        }
      });
      return;
    }
    if (tag === 'TABLE') {
      const htmlRows = Array.from(el.querySelectorAll('tr'));
      if (htmlRows.length === 0) return;

      const rows = htmlRows.map((tr) => {
        const htmlCells = Array.from(tr.children).filter(
          (c) => c.tagName === 'TD' || c.tagName === 'TH'
        ) as HTMLElement[];
        return new TableRow({
          children: htmlCells.map((cell) => {
            const isHeader = cell.tagName === 'TH';
            const runs = extractTextRuns(
              cell,
              { bold: isHeader },
              defaultFont,
              defaultHalfPt
            );
            return new TableCell({
              shading: isHeader ? { fill: 'F1F5F9' } : undefined,
              children: [
                new Paragraph({
                  spacing: { line: 260, after: 60 },
                  children: runs.length > 0 ? runs : [new TextRun('')],
                }),
              ],
            });
          }),
        });
      });

      docChildren.push(
        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows,
        })
      );
      docChildren.push(new Paragraph({ children: [] }));
      return;
    }

    if (tag === 'DIV' && el.children.length > 0) {
      const hasBlockChildren = Array.from(el.children).some((c) =>
        ['P', 'DIV', 'H1', 'H2', 'H3', 'UL', 'OL', 'TABLE', 'BLOCKQUOTE', 'HR'].includes(
          c.tagName
        )
      );
      if (hasBlockChildren) {
        Array.from(el.childNodes).forEach(processNode);
        return;
      }
    }

    pushParagraphFromElement(el);
  };

  Array.from(root.childNodes).forEach(processNode);

  if (docChildren.length === 0) {
    docChildren.push(new Paragraph({ children: [new TextRun('')] }));
  }

  const pageSizeTwip = getPaperDimensionsTwip(settings);

  const doc = new Document({
    title,
    creator: 'FolioWord',
    numbering: {
      config: [
        {
          reference: 'folio-numbered-list',
          levels: [
            {
              level: 0,
              format: 'decimal',
              text: '%1.',
              alignment: AlignmentType.START,
              style: {
                paragraph: {
                  indent: { left: convertInchesToTwip(0.5), hanging: convertInchesToTwip(0.25) },
                },
              },
            },
          ],
        },
      ],
    },
    sections: [
      {
        properties: {
          page: {
            size: {
              width: pageSizeTwip.width,
              height: pageSizeTwip.height,
              orientation:
                settings.orientation === 'landscape'
                  ? PageOrientation.LANDSCAPE
                  : PageOrientation.PORTRAIT,
            },
            margin: {
              top: convertInchesToTwip(settings.margins.top),
              bottom: convertInchesToTwip(settings.margins.bottom),
              left: convertInchesToTwip(settings.margins.left),
              right: convertInchesToTwip(settings.margins.right),
            },
          },
        },
        headers:
          settings.showHeaderFooter && settings.headerText.trim()
            ? {
                default: new Header({
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.RIGHT,
                      children: [
                        new TextRun({
                          text: settings.headerText,
                          font: defaultFont,
                          size: 18,
                          color: '64748B',
                        }),
                      ],
                    }),
                  ],
                }),
              }
            : undefined,
        footers:
          settings.showHeaderFooter && settings.footerText.trim()
            ? {
                default: new Footer({
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: settings.footerText,
                          font: defaultFont,
                          size: 18,
                          color: '64748B',
                        }),
                      ],
                    }),
                  ],
                }),
              }
            : undefined,
        children: docChildren,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  triggerDownload(blob, `${sanitizeFilename(title)}.docx`);
}

export function exportToHtml(title: string, htmlContent: string, settings: PageSettings): void {
  const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(title)}</title>
<style>
  body {
    font-family: ${settings.defaultFontFamily};
    font-size: ${settings.defaultFontSizePt}pt;
    line-height: ${settings.lineHeight};
    max-width: 8.5in;
    margin: ${settings.margins.top}in auto;
    padding: 0 ${settings.margins.left}in;
    color: #111827;
  }
  table { border-collapse: collapse; width: 100%; margin: 1em 0; }
  td, th { border: 1px solid #cbd5e1; padding: 6px 10px; }
  th { background: #f1f5f9; text-align: left; }
  blockquote { margin: 1em 0; padding: 0.75em 1.25em; background: #f8fafc; border: 1px solid #e2e8f0; font-style: italic; }
</style>
</head>
<body>
${htmlContent}
</body>
</html>`;
  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  triggerDownload(blob, `${sanitizeFilename(title)}.html`);
}

export function exportToPlainText(title: string, plainText: string): void {
  const blob = new Blob([plainText], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, `${sanitizeFilename(title)}.txt`);
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function sanitizeFilename(name: string): string {
  return (name || 'Untitled Document').replace(/[\\/:*?"<>|]+/g, '_').trim() || 'Document';
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
