import { PageSettings, TemplatePreset } from '../types/document';

export const DEFAULT_PAGE_SETTINGS: PageSettings = {
  paperSize: 'letter',
  orientation: 'portrait',
  margins: {
    top: 1,
    bottom: 1,
    left: 1,
    right: 1,
  },
  columns: 1,
  lineHeight: 1.5,
  paragraphSpacingAfter: 0.75,
  defaultFontFamily: 'Source Serif 4, Georgia, serif',
  defaultFontSizePt: 11,
  showRuler: true,
  showHeaderFooter: false,
  headerText: '',
  footerText: '',
  pageTone: 'white',
};

export const DOCUMENT_TEMPLATES: TemplatePreset[] = [
  {
    id: 'blank',
    title: 'Blank Document',
    category: 'Blank',
    description: 'Clean, unformatted digital page ready for writing.',
    defaultTitle: 'Untitled Document',
    html: '<p><br></p>',
    settings: {
      paperSize: 'letter',
      orientation: 'portrait',
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      columns: 1,
      lineHeight: 1.5,
      defaultFontFamily: 'Source Serif 4, Georgia, serif',
      defaultFontSizePt: 11,
      showHeaderFooter: false,
    },
  },
  {
    id: 'mla-essay',
    title: 'Academic Essay (MLA)',
    category: 'Academic',
    description: 'Double-spaced academic paper with header block, thesis structure, and Works Cited section.',
    defaultTitle: 'Climate Resilience Essay',
    html: `<p>Elena Rostova</p>
<p>Professor Marcus Vance</p>
<p>Environmental Policy 302</p>
<p>14 November 2026</p>
<h1 style="text-align: center;">Urban Canopy Equity and Heat-Island Mitigation</h1>
<p>Across major metropolitan corridors, summer peak temperatures routinely diverge by up to seven degrees Celsius between affluent tree-lined neighborhoods and historically industrial districts. Recent municipal forestry initiatives demonstrate that targeted canopy expansion can reduce ambient street-level heat while lowering residential cooling demand during extreme weather events.</p>
<p>To evaluate these outcomes, researchers tracked three mid-sized cities over a five-year planting cycle. Neighborhoods receiving priority native tree corridors experienced measurable reductions in afternoon surface temperatures, improved stormwater retention, and higher pedestrian activity throughout the warmer months.</p>
<h2>Policy Implications for Municipal Planning</h2>
<p>Effective urban forestry requires long-term maintenance budgets alongside initial sapling installation. When local agencies pair canopy targets with community stewardship grants, survival rates for newly planted trees rise substantially over the first thirty-six months.</p>
<blockquote>"Equitable green infrastructure treats shade and clean air as essential public utilities rather than ornamental amenities."</blockquote>
<h2>Works Cited</h2>
<p>Alvarez, Sofia. <em>Cool Cities: Canopy Planning for Resilient Neighborhoods</em>. Civic Press, 2025.</p>
<p>Chen, David, and Hannah Okafor. "Measuring Microclimate Shifts in Post-Industrial Corridors." <em>Journal of Urban Ecology</em>, vol. 18, no. 2, 2026, pp. 114–132.</p>`,
    settings: {
      paperSize: 'letter',
      orientation: 'portrait',
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      columns: 1,
      lineHeight: 2.0,
      defaultFontFamily: 'Source Serif 4, Georgia, serif',
      defaultFontSizePt: 12,
      showHeaderFooter: true,
      headerText: 'Rostova | Urban Canopy Equity',
      footerText: 'Page 1',
    },
  },
  {
    id: 'business-report',
    title: 'Quarterly Business Report',
    category: 'Corporate',
    description: 'Executive summary, financial metrics table, operational milestones, and Q4 outlook.',
    defaultTitle: 'Q3 Operations & Revenue Report',
    html: `<h1>Q3 Operations &amp; Revenue Report</h1>
<p><strong>Prepared by:</strong> Corporate Strategy &amp; Finance · <strong>Period:</strong> July – September 2026</p>
<hr>
<h2>1. Executive Summary</h2>
<p>Third-quarter performance exceeded baseline projections across core enterprise accounts, driven by stronger multi-year renewals and disciplined operating expenses. Net revenue retention climbed to 114%, while onboarding cycle times decreased by six business days compared with the prior quarter.</p>
<h2>2. Financial Highlights</h2>
<table>
  <thead>
    <tr>
      <th>Metric</th>
      <th>Q2 Actual</th>
      <th>Q3 Actual</th>
      <th>QoQ Change</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Annual Recurring Revenue</td>
      <td>$14.2M</td>
      <td>$15.9M</td>
      <td>+12.0%</td>
    </tr>
    <tr>
      <td>Gross Margin</td>
      <td>76.4%</td>
      <td>78.1%</td>
      <td>+1.7 pts</td>
    </tr>
    <tr>
      <td>Net Customer Retention</td>
      <td>111%</td>
      <td>114%</td>
      <td>+3.0 pts</td>
    </tr>
  </tbody>
</table>
<h2>3. Key Operational Milestones</h2>
<ul>
  <li>Completed regional data residency rollout across Frankfurt and Dublin clusters ahead of schedule.</li>
  <li>Reduced average customer support first-response latency from 4.2 hours to 1.8 hours.</li>
  <li>Published revised vendor security compliance handbook for all enterprise procurement teams.</li>
</ul>
<h2>4. Fourth-Quarter Priorities</h2>
<p>Leadership will concentrate Q4 capital allocation on automated billing reconciliation, self-serve enterprise provisioning, and partner enablement across mid-market territories.</p>`,
    settings: {
      paperSize: 'letter',
      orientation: 'portrait',
      margins: { top: 0.85, bottom: 0.85, left: 0.9, right: 0.9 },
      columns: 1,
      lineHeight: 1.45,
      defaultFontFamily: 'Plus Jakarta Sans, Arial, sans-serif',
      defaultFontSizePt: 10.5,
      showHeaderFooter: true,
      headerText: 'Northstar Systems — Confidential Internal Report',
      footerText: 'Q3 FY2026 Financial & Operational Review',
    },
  },
  {
    id: 'executive-memo',
    title: 'Executive Memorandum',
    category: 'Corporate',
    description: 'Structured internal memo with To/From/Date/Subject block and action items.',
    defaultTitle: 'Project Horizon Launch Memo',
    html: `<h1>Memorandum</h1>
<p><strong>To:</strong> Product &amp; Engineering Leadership<br><strong>From:</strong> Claire Bennett, VP of Operations<br><strong>Date:</strong> November 14, 2026<br><strong>Subject:</strong> Readiness Review for Project Horizon General Availability</p>
<hr>
<h2>Purpose</h2>
<p>This memorandum outlines the final readiness checklist ahead of next month's general availability release. All core teams have completed integration testing, and documentation review is now underway.</p>
<h2>Action Items Before Release</h2>
<ol>
  <li>Finalize customer migration guides and publish release notes to the knowledge base by November 20.</li>
  <li>Conduct load-failover rehearsal with infrastructure and on-call leads on November 24.</li>
  <li>Confirm regional support staffing coverage for the initial 72-hour launch window.</li>
</ol>
<p>Please submit any blocking risks directly to the release coordinator prior to Friday's readiness sign-off.</p>`,
    settings: {
      paperSize: 'letter',
      orientation: 'portrait',
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      columns: 1,
      lineHeight: 1.5,
      defaultFontFamily: 'DM Sans, Arial, sans-serif',
      defaultFontSizePt: 11,
      showHeaderFooter: false,
    },
  },
  {
    id: 'cover-letter',
    title: 'Professional Cover Letter',
    category: 'Personal',
    description: 'Clean formal letter layout with sender header, salutation, and signature block.',
    defaultTitle: 'Cover Letter — Senior Analyst',
    html: `<p><strong>Jordan Patel</strong><br>418 Mercer Street, Suite 4B · Seattle, WA 98109<br>jordan.patel@example.com · (206) 555-0194</p>
<p>November 14, 2026</p>
<p>Hiring Committee<br>Cascade Analytics Group<br>Seattle, WA</p>
<p>Dear Hiring Committee,</p>
<p>I am writing to express my enthusiasm for the Senior Operations Analyst position at Cascade Analytics Group. Over the past five years, I have led cross-functional forecasting initiatives that translated complex supply-chain datasets into clear executive decisions.</p>
<p>In my current role at Harbor Logistics, I redesigned our weekly demand-planning model, reducing inventory stockouts by 18% while cutting manual spreadsheet reconciliation time in half. Collaborating closely with finance, procurement, and regional warehouse managers taught me how to communicate analytical findings with clarity and practical urgency.</p>
<p>I would welcome the opportunity to bring this blend of quantitative rigor and operational storytelling to your team. Thank you for your time and consideration.</p>
<p>Sincerely,<br><br>Jordan Patel</p>`,
    settings: {
      paperSize: 'letter',
      orientation: 'portrait',
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      columns: 1,
      lineHeight: 1.45,
      defaultFontFamily: 'Lora, Georgia, serif',
      defaultFontSizePt: 11,
      showHeaderFooter: false,
    },
  },
];
