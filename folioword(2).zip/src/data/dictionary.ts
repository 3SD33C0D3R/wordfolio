// Compact high-coverage English lexicon + common misspelling map + morphological stemmer

export const COMMON_MISSPELLINGS: Record<string, string[]> = {
  teh: ['the'],
  hte: ['the'],
  adn: ['and'],
  nad: ['and'],
  taht: ['that'],
  tath: ['that'],
  wiht: ['with'],
  wtih: ['with'],
  fo: ['of'],
  ot: ['to'],
  si: ['is'],
  ti: ['it'],
  hteir: ['their'],
  thier: ['their'],
  theri: ['their'],
  recieve: ['receive'],
  recieved: ['received'],
  recieving: ['receiving'],
  beleive: ['believe'],
  belive: ['believe'],
  acheive: ['achieve'],
  acheived: ['achieved'],
  seperate: ['separate'],
  seperated: ['separated'],
  seperately: ['separately'],
  definately: ['definitely'],
  definatly: ['definitely'],
  definetly: ['definitely'],
  occured: ['occurred'],
  occuring: ['occurring'],
  occurr: ['occur'],
  untill: ['until'],
  wich: ['which'],
  whihc: ['which'],
  becuase: ['because'],
  beacuse: ['because'],
  becasue: ['because'],
  accomodate: ['accommodate'],
  acommodate: ['accommodate'],
  recomend: ['recommend'],
  reccommend: ['recommend'],
  recomment: ['recommend'],
  neccessary: ['necessary'],
  necesary: ['necessary'],
  nessasary: ['necessary'],
  goverment: ['government'],
  govenment: ['government'],
  enviroment: ['environment'],
  environement: ['environment'],
  independant: ['independent'],
  independance: ['independence'],
  apperance: ['appearance'],
  appearence: ['appearance'],
  begining: ['beginning'],
  bussiness: ['business'],
  buisness: ['business'],
  busness: ['business'],
  calender: ['calendar'],
  catagory: ['category'],
  cemetary: ['cemetery'],
  changable: ['changeable'],
  collectable: ['collectible'],
  collegue: ['colleague'],
  comming: ['coming'],
  commitee: ['committee'],
  committe: ['committee'],
  completly: ['completely'],
  concious: ['conscious'],
  consious: ['conscious'],
  curiousity: ['curiosity'],
  decieve: ['deceive'],
  desparate: ['desperate'],
  develope: ['develop'],
  diferent: ['different'],
  diffrent: ['different'],
  disapoint: ['disappoint'],
  dissapoint: ['disappoint'],
  embarass: ['embarrass'],
  embarassing: ['embarrassing'],
  equiptment: ['equipment'],
  exagerate: ['exaggerate'],
  excellant: ['excellent'],
  existance: ['existence'],
  experiance: ['experience'],
  experince: ['experience'],
  explaination: ['explanation'],
  facinating: ['fascinating'],
  familar: ['familiar'],
  finaly: ['finally'],
  florescent: ['fluorescent'],
  foriegn: ['foreign'],
  fourty: ['forty'],
  foward: ['forward'],
  freind: ['friend'],
  frend: ['friend'],
  fulfill: ['fulfill'],
  guage: ['gauge'],
  grammer: ['grammar'],
  gratefull: ['grateful'],
  greatful: ['grateful'],
  gaurd: ['guard'],
  happend: ['happened'],
  harrass: ['harass'],
  heigth: ['height'],
  heros: ['heroes'],
  humourous: ['humorous'],
  hygeine: ['hygiene'],
  ignorant: ['ignorant'],
  immediatly: ['immediately'],
  immedietly: ['immediately'],
  incidently: ['incidentally'],
  infomation: ['information'],
  infromation: ['information'],
  inteligence: ['intelligence'],
  intelligance: ['intelligence'],
  intresting: ['interesting'],
  interupt: ['interrupt'],
  irresistable: ['irresistible'],
  knowlege: ['knowledge'],
  knowldge: ['knowledge'],
  langauge: ['language'],
  leasure: ['leisure'],
  liason: ['liaison'],
  libary: ['library'],
  lisence: ['license'],
  maintainance: ['maintenance'],
  maintenence: ['maintenance'],
  managment: ['management'],
  mangement: ['management'],
  millenium: ['millennium'],
  miniscule: ['minuscule'],
  mischevious: ['mischievous'],
  mispell: ['misspell'],
  morgage: ['mortgage'],
  noticable: ['noticeable'],
  occassion: ['occasion'],
  ocassion: ['occasion'],
  ocasion: ['occasion'],
  omision: ['omission'],
  oppertunity: ['opportunity'],
  oportunity: ['opportunity'],
  orignal: ['original'],
  outragous: ['outrageous'],
  parliment: ['parliament'],
  passtime: ['pastime'],
  peculiar: ['peculiar'],
  percieve: ['perceive'],
  performence: ['performance'],
  perminent: ['permanent'],
  persistance: ['persistence'],
  personel: ['personnel'],
  pharoah: ['pharaoh'],
  peice: ['piece'],
  plagarize: ['plagiarize'],
  posession: ['possession'],
  posible: ['possible'],
  potatos: ['potatoes'],
  preceed: ['precede'],
  prefered: ['preferred'],
  presance: ['presence'],
  principel: ['principal', 'principle'],
  priviledge: ['privilege'],
  privilige: ['privilege'],
  probly: ['probably'],
  probaly: ['probably'],
  profesional: ['professional'],
  proffesional: ['professional'],
  promiss: ['promise'],
  pronounciation: ['pronunciation'],
  propoganda: ['propaganda'],
  publically: ['publicly'],
  pursue: ['pursue'],
  quater: ['quarter'],
  questionaire: ['questionnaire'],
  readible: ['readable'],
  realy: ['really'],
  relly: ['really'],
  reccomend: ['recommend'],
  rediculous: ['ridiculous'],
  refered: ['referred'],
  referance: ['reference'],
  refrence: ['reference'],
  rehersal: ['rehearsal'],
  relevent: ['relevant'],
  religous: ['religious'],
  rember: ['remember'],
  remeber: ['remember'],
  repetion: ['repetition'],
  resistence: ['resistance'],
  responsability: ['responsibility'],
  restaraunt: ['restaurant'],
  resaurant: ['restaurant'],
  rythm: ['rhythm'],
  rythem: ['rhythm'],
  sacrilegious: ['sacrilegious'],
  sargent: ['sergeant'],
  scedule: ['schedule'],
  shedule: ['schedule'],
  secratary: ['secretary'],
  sence: ['sense'],
  sentance: ['sentence'],
  serivce: ['service'],
  sevice: ['service'],
  shoud: ['should'],
  shoudl: ['should'],
  similiar: ['similar'],
  sincerly: ['sincerely'],
  speach: ['speech'],
  statment: ['statement'],
  strangly: ['strangely'],
  stratagy: ['strategy'],
  strenght: ['strength'],
  studing: ['studying'],
  sucess: ['success'],
  succesful: ['successful'],
  sucessful: ['successful'],
  supercede: ['supersede'],
  suposed: ['supposed'],
  supprise: ['surprise'],
  suprise: ['surprise'],
  temperment: ['temperament'],
  temperture: ['temperature'],
  tendancy: ['tendency'],
  therefor: ['therefore'],
  thoroughly: ['thoroughly'],
  threshhold: ['threshold'],
  tommorow: ['tomorrow'],
  tomorow: ['tomorrow'],
  tounge: ['tongue'],
  truely: ['truly'],
  trully: ['truly'],
  twelth: ['twelfth'],
  tyrany: ['tyranny'],
  underate: ['underrate'],
  unfortunatly: ['unfortunately'],
  univeristy: ['university'],
  unusal: ['unusual'],
  usefull: ['useful'],
  usally: ['usually'],
  usualy: ['usually'],
  vaccum: ['vacuum'],
  vegtable: ['vegetable'],
  vehical: ['vehicle'],
  visable: ['visible'],
  wether: ['whether', 'weather'],
  woudl: ['would'],
  writting: ['writing'],
  writen: ['written'],
  yeild: ['yield'],
  alot: ['a lot'],
  documnt: ['document'],
  docuemnt: ['document'],
  reprot: ['report'],
  repot: ['report'],
  anaylsis: ['analysis'],
  analysys: ['analysis'],
  summery: ['summary'],
  sumary: ['summary'],
  exeutive: ['executive'],
  exective: ['executive'],
  finanical: ['financial'],
  fianncial: ['financial'],
  revenu: ['revenue'],
  revnue: ['revenue'],
  quaterly: ['quarterly'],
  quartely: ['quarterly'],
  paragrah: ['paragraph'],
  esay: ['essay'],
  essy: ['essay'],
  concusion: ['conclusion'],
  conculsion: ['conclusion'],
  introdction: ['introduction'],
  introducton: ['introduction'],
  evidance: ['evidence'],
  arguement: ['argument'],
  argumnet: ['argument'],
  reasearch: ['research'],
  reserch: ['research'],
  signifcant: ['significant'],
  significnt: ['significant'],
  improtant: ['important'],
  importnt: ['important'],
  effecient: ['efficient'],
  efficent: ['efficient'],
  organiztion: ['organization'],
  organzation: ['organization'],
  communiction: ['communication'],
  comunication: ['communication'],
  collabortion: ['collaboration'],
  colaboration: ['collaboration'],
  implemnt: ['implement'],
  implment: ['implement'],
  strategc: ['strategic'],
  stretegic: ['strategic'],
  objecive: ['objective'],
  objectve: ['objective'],
  deliverble: ['deliverable'],
  milstone: ['milestone'],
  schedle: ['schedule'],
  budgetry: ['budgetary'],
  proeject: ['project'],
  porject: ['project'],
  tehcnology: ['technology'],
  techonology: ['technology'],
  custmer: ['customer'],
  customr: ['customer'],
  clinet: ['client'],
  stakeholer: ['stakeholder'],
  stakehlder: ['stakeholder'],
  meetng: ['meeting'],
  meting: ['meeting'],
};

// Space-separated core English vocabulary (root words, function words, academic & corporate lexicon)
const RAW_LEXICON = `
a about above absence absolute abstract academic accelerate accept access accident accommodate accompany accomplish according account accurate achieve acid acquire across act action active activity actual adapt add addition additional address adequate adjust administration administrative admit adopt adult advance advantage adventure advertise advice advise advocate affair affect afford afraid after afternoon again against age agency agenda agent ago agree agreement ahead aid aim air aircraft airline airport alarm album alcohol alert alike alive all allege allocate allow almost alone along already also alter alternative although altogether always amazing ambition among amount ample amplify analyze analysis analyst ancient and anger angle angry animal announce annual another answer anticipate anxiety any anybody anyone anything anyway anywhere apart apartment apparent appeal appear appearance apple application apply appoint appreciate approach appropriate approval approve approximate april arch architect architecture archive area argue argument arise arm army around arrange arrangement array arrest arrive arrow art article artificial artist as ashamed aside ask aspect assemble assert assess asset assign assist assistance assistant associate assume assumption assure astonish at athlete atmosphere attach attack attain attempt attend attention attitude attorney attract attractive attribute audience audit august author authority auto automatic autumn available avenue average avoid awake award aware away awful awkward
baby back background backward bacteria bad badly bag bake balance ball ban band bank bar bare barely bargain bark barrel barrier base basic basis basket bat bath battery battle be beach beam bean bear beard beast beat beautiful beauty became because become bed bedroom bee beef been before began begin beginning behalf behave behavior behind being belief believe bell belong below belt bench bend beneath benefit beside besides best bet better between beyond bias bicycle bid big bike bill billion bind bio biology bird birth birthday bit bite bitter black blade blame blank blanket blast bleed blend bless blind block blonde blood bloom blow blue board boast boat body boil bold bolt bomb bond bone bonus book boom boost boot border bore born borrow boss both bother bottle bottom bounce bound boundary bow bowl box boy brain branch brand brave bread break breakfast breast breath breathe breed breeze brick bride bridge brief bright brilliant bring broad broke broken bronze brother brought brown brush bubble buck bucket budget build building built bulk bullet bunch bundle burden bureau burn burst bury bus bush business busy but butter button buy buyer by
cab cabin cabinet cable cafe cage cake calculate calendar calf call calm came camera camp campaign campus can canal cancel cancer candidate candle candy canvas cap capable capacity capital captain capture car carbon card care career careful carefully cargo carpet carry cart case cash cast castle casual cat catalog catch category cattle cause caution cave cease ceiling celebrate celebration cell center central century ceremony certain certainly certainty chain chair chairman challenge chamber champion chance change channel chaos chapter character characteristic charge charity charm chart charter chase cheap cheat check cheek cheer cheese chef chemical chemistry chest chew chicken chief child childhood children chill chin chip chocolate choice choose chop chord chorus chose chosen chronic church cigarette cinema circle circuit circumstance cite citizen city civil civilian claim clamp clap clarify clarity class classic classical classify classroom clause clay clean clear clearly clerk clever click client cliff climate climb cling clinic clip clock close closely closer closest cloth clothes clothing cloud club clue cluster coach coal coast coat code coffee cognitive coin coincide cold collapse collar colleague collect collection collective college collision colonial colony color column combat combine come comedy comfort comfortable command comment commerce commercial commission commit commitment committee common commonly communicate communication community compact companion company compare comparison compete competence competition competitive compile complain complaint complete completely complex complexity compliance comply component compose composition compound comprehensive comprise compromise compute computer conceal concede conceive concentrate concentration concept concern concerned concerning concert conclude conclusion concrete condemn condition conduct confer conference confess confidence confident confirm conflict conform confront confuse confusion congress connect connection conscious consensus consent consequence conservative consider considerable considerably consideration consist consistent consolidate constant constantly constitute constitution construct construction consult consultant consume consumer consumption contact contain container contemporary content contest context continue continuous contract contradict contrary contrast contribute contribution control controversial controversy convenience convenient convention conventional conversation convert convey convince cook cookie cool cooperate cooperation coordinate cope copy copyright cord core corn corner corporate corporation correct correction correlate correspond corridor cost costly cottage cotton could council counsel count counter counterpart country countryside county couple courage course court cousin cover coverage cow crack craft crash crawl crazy cream create creation creative creativity creator creature credit creek crew cricket crime criminal crisis crisp criteria criterion critic critical criticism critique crop cross crowd crown crucial crude cruel cruise crush cry crystal cube cue cultivate cultural culture cup cupboard curb cure curiosity curious current currently curriculum curse curtain curve custom customer cut cute cycle
dad daily damage damp dance danger dangerous dare dark darkness data database date daughter dawn day dead deadline deal dealer dear death debate debt decade decay decent decide decision deck declare decline decorate decrease dedicate deed deep deeply default defeat defend defense deficit define definite definitely definition degree delay delegate delete deliberate delicate delight deliver delivery demand democracy democratic demonstrate demonstration denial dense density deny depart department departure depend dependent depict deploy deposit depress depth derive describe description desert deserve design designate designer desire desk despair desperate despite destroy destruction detail detect detective determine develop developer development device devil devise devote dialogue diamond diary dictate dictionary did die diet differ difference different differently difficult difficulty dig digest digital dignity dilemma dimension diminish dine dinner dip direct direction directly director dirt dirty disagree disappear disappoint disaster disc discipline disclose discount discourse discover discovery discovery discuss discussion disease dish disk dismiss disorder display dispute dissolve distance distant distinct distinguish distort distribute distribution district disturb dive diverse diversity divide dividend divine division divorce do doctor doctrine document dodge dog dollar domain domestic dominant dominate donate donation done donor door dose dot double doubt dough down downtown dozen draft drag drain drama dramatic dramatically draw drawer drawing dream dress drift drill drink drive driver drop drought drown drug drum dry duck due dull dumb dump duplicate during dust duty dwarf dwell dynamic
each eager ear early earn earnest earth ease easily east eastern easy eat echo ecological economic economics economy edge edit edition editor educate education effect effective effectively efficiency efficient effort egg eight eighteen eighth eighty either elaborate elbow elder elderly elect election electric electricity electronic elegant element elementary elephant elevate eleven eligible eliminate elite else elsewhere email embark embarrass embassy embed embrace emerge emergency emission emotion emotional emphasis emphasize empire employ employee employer employment empty enable enact enclose encounter encourage end endless endorse endure enemy energy enforce engage engine engineer enhance enjoy enormous enough enrich enroll ensure enter enterprise entertain enthusiasm entire entirely entitle entity entrance entry envelope environment environmental envy episode equal equally equation equip equipment equivalent era erase erect error escape especially essay essence essential establish establishment estate estimate eternal ethic ethical evaluate evaluation even evening event eventually ever every everybody everyday everyone everything everywhere evidence evident evil evoke evolve exact exactly exam examine example exceed excellence excellent except exception excess excessive exchange excite excitement exclude exclusive excuse execute execution executive exercise exhaust exhibit exhibition exist existence exit expand expansion expect expectation expend expense expensive experience experiment expert explain explanation explicit explode exploit explore explosion export expose exposure express expression extend extension extensive extent external extra extract extraordinary extreme extremely eye
fabric face facilitate facility fact factor factory faculty fade fail failure faint fair fairly faith fall false fame familiar family famous fan fancy fantastic far fare farm farmer fashion fast fasten fat fatal fate father fatigue fault favor favorable favorite fear feast feather feature february federal fee feed feel feeling feet fellow female fence fertile festival fetch fever few fiber fiction field fierce fifteen fifth fifty fight figure file fill film filter final finally finance financial find finding fine finger finish finite fire firm firmly first fiscal fish fist fit fitness five fix fixed flag flame flash flat flavor flaw flee fleet flesh flexibility flexible flight flip float flock flood floor flour flourish flow flower fluid flush fly foam focus fog fold folk follow following fond food fool foot football for forbid force forecast foreign forest forever forget forgive fork form formal format formation former formerly formula formulate forth forthcoming fortnight fortunate fortunately fortune forty forward fossil foster fought found foundation founder fountain four fourteen fourth fox fraction fragile fragment frame framework frank frankly fraud free freedom freeze freight french frequent frequently fresh friction friday friend friendly friendship frighten frog from front frost frown frozen fruit frustrate frustration fuel fulfill full fully fun function fund fundamental funding funeral funny fur furious furnace furnish furniture further furthermore fury fuse future
gain galaxy gallery gallon gamble game gang gap garage garbage garden garlic garment gas gasp gate gather gauge gave gay gaze gear gender gene general generally generate generation generous genetic genius genre gentle gently genuine geography geology geometry gesture get ghost giant gift gifted giggle girl give given glad glance glare glass gleam glide glimpse global globe gloom glory gloss glove glow glue go goal goat god gold golden golf gone good goodbye goods goose gorgeous gospel gossip got govern governance government governor grab grace graceful grade gradual gradually grain gram grammar grand grandfather grandmother grant grape graph grasp grass grateful gratitude grave gravel gravity gray great greatly green greet grey grid grief grill grim grin grind grip groan grocery groom groove gross ground group grow growth guarantee guard guess guest guidance guide guideline guilt guilty guitar gulf gullible gun gut guy gym
habit habitat hack hail hair half hall halt hammer hand handful handle handsome hang happen happily happiness happy harbor hard hardly hardware harm harmony harsh harvest haste hasty hat hatch hate haul have haven hazard he head headache headline headquarters health healthy heap hear heard hearing heart heat heaven heavy heck hedge heel height heir held helicopter hell hello helmet help helpful helpless hemisphere hence her herb herd here heritage hero heroic hesitate hey hidden hide high highlight highly highway hike hill him himself hint hip hire his historian historic historical history hit hive hobby hockey hold holder hole holiday hollow holy home homeless homework honest honestly honesty honey honor hook hope hopeful hopefully horizon horizontal horn horror horse hospital host hostage hostile hot hotel hour hourglass house household housing how however huge human humanity humble humor hundred hung hunger hungry hunt hurdle hurl hurry hurt husband hut hybrid hydrogen hygiene hypothesis
i ice icon idea ideal identical identify identity ideology idle if ignore ill illegal illness illuminate illusion illustrate illustration image imagination imagine immediate immediately immense immerse immigrant immune impact impair impart impatient implement implication imply import importance important impose impossible impress impression impressive improve improvement impulse in incentive incident include including income incorporate increase increasing increasingly incredible indeed independence independent index indicate indication indicator indigenous indirect individual induce industrial industry inevitable inevitably infant infect infection infer inference infinite inflation influence inform informal information infrastructure ingredient inhabit inherent inherit initial initially initiate initiative inject injure injury ink inland inner innocent innovation input inquire inquiry insect insert inside insight insist inspect inspection inspire install instance instant instead instinct institute institution instruct instruction instructor instrument insufficient insult insure intact integrate integrity intellect intellectual intelligence intelligent intend intense intensity intent intention interact interaction interest interesting interfere interior internal international interpret interpretation interval intervene intervention interview intimate into introduce introduction invade invasion invent invention invest investigate investigation investment investor invisible invite involve involvement iron irony irrelevant island isolate isolation issue it item its itself
jacket jail jam january jar jaw jazz jealous jeans jelly jerk jet jewel jewelry job join joint joke journal journalism journalist journey joy judge judgment judicial juice jump junction june junior jury just justice justify
keen keep kept kernel kettle key keyboard kick kid kidnap kidney kill killer kilometer kind kindly kindness king kingdom kiss kit kitchen kite knee kneel knew knife knight knit knock knot know knowledge known
lab label labor laboratory lace lack ladder lady laid lake lamb lamp land landing landlord landmark landscape lane language lap laptop large largely laser last late lately later latest latter laugh laughter launch laundry law lawn lawsuit lawyer lay layer layout lazy lead leader leadership leading leaf leaflet league leak lean leap learn learned learning lease least leather leave lecture led ledge left leg legacy legal legend legislation legitimate leisure lemon lend length lens less lesson let letter level lever liability liable liar liberal liberate liberty library license lid lie life lifestyle lift light lighten lightning like likelihood likely likewise limb limit limitation limited line linear linger link lion lip liquid list listen listener literally literary literature little live lively liver living load loaf loan lobby local locate location lock lodge log logic logical lone lonely long look loop loose loosen lord lose loss lost lot loud loudly lounge love lovely lover low lower loyal loyalty luck lucky luggage lumber lump lunch lung luxury lyric
machine machinery mad made magazine magic magnetic magnificent magnitude maid mail main mainly maintain maintenance major majority make maker makeup male mall mama mammal man manage management manager mandate manipulate manner mansion manual manufacture manufacturer many map marble march margin marine mark market marketing marriage married marry mask mass massive master match mate material math mathematics matter mature max maximum may maybe mayor me meal mean meaning meaningful means meanwhile measure measurement meat mechanic mechanical mechanism medal media medical medicine medium meet meeting melt member membership memory mental mention menu merchandise merchant mercy mere merely merge merit merry mesh mess message messenger metal metaphor meter method methodology metric metropolitan mice micro microphone microscope mid middle midnight might mighty migrate mild mile military milk mill million mind mine mineral minimal minimize minimum minister ministry minor minority minus minute miracle mirror misery miss missile missing mission mistake mix mixture mobile mode model moderate modern modest modify module moist moisture mold molecule mom moment momentum monday money monitor monkey monster month monthly mood moon moral morale more moreover morning mortal mortgage most mostly mother motion motivate motivation motive motor mount mountain mouse mouth move movement movie much mud multiple multiply murder muscle museum music musical musician must mutual my myself mysterious mystery myth
nail naive naked name namely narrative narrow nation national native natural naturally nature naval navigate navigation near nearby nearly neat neatly necessary necessity neck need needle negative neglect negotiate negotiation neighbor neighborhood neither nerve nervous nest net network neutral never nevertheless new newly news newspaper next nice nicely niche nickel niece night nightmare nine nineteen ninety ninth nitrogen no noble nobody nod noise noisy nominal none nonetheless noon nor norm normal normally north northern nose not notable notably note notebook nothing notice noticeable notify notion noun novel november now nowhere nuclear nude number numerous nurse nursery nut nutrition
o'clock oak oar oasis oat oath obey object objection objective obligation oblige obscure observe observer obstacle obtain obvious obviously occasion occasional occasionally occupy occur occurrence ocean october odd oddly odds of off offend offense offensive offer offering office officer official often oh oil okay old olympic omit on once one ongoing onion online only onto open opening openly operate operation operational operator opinion opponent opportunity oppose opposite opposition opt optic optical optimism optimistic option or oral orange orbit orchard order ordinary organ organic organism organization organize orient orientation origin original originally other otherwise ought our ours ourselves out outcome outdoor outer outfit outing outlet outline output outside outstanding oval oven over overall overcome overflow overhead overlap overlook overnight overseas oversee owe owl own owner ownership ox
pace pack package packet pad page paid pain painful paint painter painting pair palace pale palm pan panel panic pant pants paper parade paradigm paragraph parallel parameter parcel pardon parent park parking parliament part partial partially participant participate participation particular particularly partly partner partnership party pass passage passenger passion passive past paste pat patch patent path patience patient patrol patron pattern pause pave paw pay payment peace peaceful peak peanut pear pearl peasant peculiar pedal peek peel peer pen penalty pencil pending penetrate penguin penny people pepper per perceive percent percentage perception perfect perfectly perform performance perhaps period permanent permission permit persist person personal personality personally personnel perspective persuade persuasion pest pet petition petrol petty phase phenomenon philosophy phone photo photograph photographer photography phrase physical physically physician physics piano pick picture pie piece pier pierce pig pigeon pile pill pillar pillow pilot pin pinch pine pink pioneer pipe pit pitch pitcher pity pizza place plain plan plane planet plank plant plastic plate platform play player plaza plea plead pleasant please pleasure pledge plenty plot plow plug plunge plural plus pocket poem poet poetry point poison pole police policy polish polite political politician politics poll pollute pollution pond pool poor pop popular popularity population porch pore pork port portable portal portion portrait pose position positive possess possession possibility possible possibly post postal poster pot potato potential potentially pound pour poverty powder power powerful practical practically practice practitioner praise pray prayer preach precede precedent precious precise precisely precision predict prediction prefer preference pregnant prejudice preliminary premier premise premium prepare prescription presence present presentation preserve president presidential press pressure presumably presume pretend pretty prevail prevent previous previously prey price pride priest primary prime primitive prince princess principal principle print printer prior priority prison prisoner privacy private privilege prize pro probability probable probably problem procedure proceed process produce producer product production profession professional professor profile profit program progress prohibit project prominent promise promote prompt prone pronounce proof proper properly property proportion proposal propose prosecute prosecution prospect protect protection protein protest proud prove provide provider province provision provoke psychological psychologist psychology pub public publication publicly publish publisher pull pulse pump pumpkin punch punish punishment pupil purchase pure purely purple purpose purse pursue pursuit push put puzzle
pyramid
qualify quality quantity quarter queen quest question questionnaire quick quickly quiet quietly quit quite quote
rabbit race racial rack radar radiation radical radio rage rail railroad rain rainbow raise rake rally ran ranch random range rank rapid rapidly rare rarely rat rate rather ratio rational raw ray razor reach react reaction read reader readily reading ready real realistic reality realize really realm rear reason reasonable reasonably rebel rebuild recall receive recent recently reception recession recipe recipient reckless recognize recommend recommendation record recover recovery recruit red reduce reduction refer reference reflect reflection reform refrain refresh refrigerator refuge refugee refuse regain regard regarding regardless regime region regional register regret regular regularly regulate regulation reinforce reject relate relation relationship relative relatively relax release relevant reliable relief relieve religion religious rely remain remaining remark remarkable remedy remember remind remote removal remove render renew rent repair repeat repeatedly replace reply report reporter represent representation representative republic reputation request require requirement rescue research researcher resemble reservation reserve reside resident resign resist resistance resolve resort resource respect respective respectively respond response responsibility responsible rest restaurant restore restrain restrict restriction result resume retail retain retire retirement retreat return reveal revenue reverse review revise revision revive revolution revolutionary reward rhetoric rhythm rib ribbon rice rich rid ride rider ridge ridiculous rifle right rigid rim ring riot rip ripe rise risk ritual rival river road roar roast rob robbery robot rock rocket rod rode role roll roman romantic roof room root rope rose rot rotate rough roughly round route routine row royal rub rubber rubbish rude rug ruin rule ruler rumor run runner rural rush rust
sack sacred sad sadly sadness safe safely safety said sail sailor saint sake salad salary sale salmon salt same sample sanction sand sandwich satellite satisfaction satisfy Saturday sauce save saving say scale scan scandal scare scared scary scatter scenario scene scent schedule scheme scholar scholarship school science scientific scientist scope score scorn scout scramble scratch scream screen screw script scroll scrub sculpture sea seal seam search season seat second secondary secret secretary section sector secure security see seed seek seem seen segment seize seldom select selection self sell senate senator send senior sense sensible sensitive sentence separate separately september sequence series serious seriously servant serve service session set setting settle settlement seven seventeen seventh seventy several severe severely sew sex sexual shade shadow shaft shake shall shallow shame shape share shareholder shark sharp sharply shatter shave she shed sheep sheer sheet shelf shell shelter shepherd shield shift shine shiny ship shirt shiver shock shoe shoot shop shopping shore short shortage shortly shot should shoulder shout shove show shower shrink shrug shut shuttle shy sibling sick side sidewalk siege sigh sight sign signal signature significance significant significantly silence silent silk silly silver similar similarly simple simply simulate simultaneous sin since sincere sincerely sing singer single sink sir sister sit site situate situation six sixteen sixth sixty size skate sketch ski skill skilled skin skip skirt skull sky slam slap slash slave slavery sleep sleeve slice slide slight slightly slim slip slope slot slow slowly small smart smash smell smile smoke smooth smoothly snake snap snatch sneak sniff snow so soak soap soar soccer social society sock sodium soft softly software soil solar sold soldier sole solely solid solution solve some somebody somehow someone something sometimes somewhat somewhere son song soon sophisticated sore sorrow sorry sort soul sound soup sour source south southern space span spare spark speak speaker special specialist specialize species specific specifically specification specify specimen spectacle spectrum speech speed spell spend sphere spice spider spill spin spine spiral spirit spiritual spite splash split spoil spoke spoken sponsor spoon sport spot spouse spray spread spring sprinkle spur spy squad square squeeze stable stack stadium staff stage stagger stain stair stake stale stalk stall stamp stand standard standing star stare stark start starve state statement static station statistical statistics statue status stay steady steak steal steam steel steep steer stem step stereo stern stick sticky stiff still stimulate stimulus stir stitch stock stomach stone stood stool stoop stop storage store storm story stout stove straight strain strand strange stranger strap strategic strategy straw strawberry stream street strength strengthen stress stretch strict strictly stride strike string strip stripe strive stroke strong strongly structure struggle stubborn stuck student studio study stuff stumble stump stupid style subject submit subsequent substance substantial subtle suburb succeed success successful successfully such suck sudden suddenly sue suffer sufficient sugar suggest suggestion suicide suit suitable suite sulfur sum summarize summary summer summit sun sunday sunlight sunny super superb superior supermarket supervise supervision supervisor supper supply support supporter suppose supposed supposedly supreme sure surely surface surge surgeon surgery surplus surprise surprised surprising surprisingly surrender surround survey survive survivor suspect suspend suspicion suspicious sustain swallow swamp swan swap swarm sway swear sweat sweater sweep sweet swell swept swift swim swing switch sword swore sworn symbol sympathetic sympathy symptom syndrome system systematic
table tablet tackle tactic tag tail take tale talent talk tall tame tank tap tape target task taste tax taxi tea teach teacher team tear tease technical technique technology tedious teen teenager teeth telephone telescope television tell temper temperature temple temporary tempt ten tenant tend tendency tender tennis tense tension tent tenth term terminal terminate terms terrible terribly territory terror terrorism terrorist test testify testimony text texture than thank thanks that the theater their theirs them theme themselves then theology theoretical theory therapy there thereby therefore thermal these they thick thief thin thing think third thirst thirsty thirteen thirty this thorn thorough thoroughly those though thought thoughtful thousand thread threat threaten three threshold threw throat throne through throughout throw thrown thrust thumb thunder thus tick ticket tide tidy tie tiger tight tightly tile till timber time timely tin tiny tip tire tired tissue title to tobacco today toe together toilet token told tolerate toll tomato tomorrow ton tone tongue tonight too took tool tooth top topic torch tore torn toss total totally touch tough tour tournament toward towards towel tower town toxic toy trace track tract trade tradition traditional traffic tragedy tragic trail train trainer training trait traitor transaction transcript transfer transform transition translate translation transmit transparent transport trap trash travel tray tread treasure treat treatment treaty tree tremble tremendous trend trial tribe trick trigger trim trip triumph trivial troop trophy tropical trouble trousers truck true truly trump trunk trust truth try tube tuck Tuesday tumor tune tunnel turkey turn turnover turtle twelve twenty twice twin twist two type typical typically typography
ugly ultimate ultimately umbrella unable unanimous unacceptable uncertain uncertainty uncle uncomfortable uncover under undergo undergraduate underground underline underlying understand understanding undertake undo undoubtedly uneasy unemployed unemployment unexpected unfortunately unhappy uniform union unique unit unite unity universal universe university unknown unless unlike unlikely unlimited unload unlock unnecessary unpleasant unpredictable unreal unresolved unsafe unsatisfactory unstable untidy until unto unusual unwilling up update upgrade uphold upon upper upright upset upside upstairs upward urban urge urgent us usage use used useful useless user usual usually utility utilize utter utterly
vacant vacation vaccine vacuum vague vain valid validity valley valuable value van vanish vanity variable variation variety various vary vast vector vegetable vehicle veil vein velocity velvet vendor venture verb verbal verdict verify version versus vertical very vessel vest veteran via viable vibrant vice victim victory video view viewer vigor vigorous village villain violate violation violence violent virtual virtually virtue virus visible vision visit visitor visual vital vitamin vivid vocal voice void volcano volume voluntary volunteer vote voter vow vowel voyage vulnerable
wade wag wage wagon waist wait waiter wake walk wall wallet wander want war ward warehouse warm warmth warn warning warrant warrior wash waste watch water waterfall watt wave wax way we weak weaken weakness wealth wealthy weapon wear weary weather weave web wedding Wednesday weed week weekend weekly weigh weight weird welcome welfare well west western wet whale what whatever wheat wheel when whenever where whereas whereby wherever whether which whichever while whilst whim whip whisper whistle white who whoever whole wholly whom whose why wicked wide widely widen widespread widow width wife wild wilderness wildlife will willing willingness win wind window wine wing winner winter wipe wire wisdom wise wish wit witch with withdraw withhold within without witness wolf woman women won wonder wonderful wood wooden wool word work worker workplace workshop world worldwide worm worn worry worse worship worst worth worthy would wound wove woven wrap wrath wreck wrench wrestle wrist write writer writing written wrong wrote
yard yarn yawn year yearly yell yellow yes yesterday yet yield you young younger youngest your yours yourself yourselves youth
zeal zebra zero zest zinc zip zone zoo zoom
`;

export const DICTIONARY_SET: Set<string> = (() => {
  const set = new Set<string>();
  const words = RAW_LEXICON.trim().split(/\s+/);
  for (const w of words) {
    if (w) set.add(w.toLowerCase());
  }
  // Common contractions & abbreviations
  const extras = [
    "i'm", "i've", "i'll", "i'd", "you're", "you've", "you'll", "you'd",
    "he's", "he'll", "he'd", "she's", "she'll", "she'd", "it's", "it'll",
    "we're", "we've", "we'll", "we'd", "they're", "they've", "they'll", "they'd",
    "that's", "who's", "what's", "where's", "when's", "why's", "how's", "there's",
    "here's", "isn't", "aren't", "wasn't", "weren't", "hasn't", "haven't", "hadn't",
    "doesn't", "don't", "didn't", "won't", "wouldn't", "shan't", "shouldn't",
    "can't", "cannot", "couldn't", "mustn't", "let's", "needn't", "daren't",
    "e.g", "i.e", "etc", "vs", "mr", "mrs", "ms", "dr", "prof", "inc", "ltd", "llc",
    "q1", "q2", "q3", "q4", "kpi", "kpis", "roi", "b2b", "b2c", "saas", "ai", "api",
    "pdf", "docx", "mla", "apa", "ceo", "cfo", "cto", "coo", "hr", "uk", "us", "usa", "eu",
    "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec",
    "mon", "tue", "wed", "thu", "fri", "sat", "sun",
    "email", "emails", "online", "offline", "website", "websites", "workflow", "workflows",
    "spreadsheet", "spreadsheets", "stakeholder", "stakeholders", "deliverable", "deliverables",
    "roadmap", "roadmaps", "milestone", "milestones", "onboarding", "benchmark", "benchmarks",
    "scalable", "scalability", "actionable", "cross-functional", "real-time", "long-term",
    "short-term", "year-over-year", "quarter-over-quarter", "follow-up", "decision-making",
    "data-driven", "high-level", "up-to-date", "well-known", "full-time", "part-time",
    "folioword", "wordcraft",
  ];
  for (const e of extras) set.add(e);
  return set;
})();

const IRREGULAR_KNOWN = new Set([
  'children', 'men', 'women', 'people', 'mice', 'geese', 'teeth', 'feet', 'oxen',
  'was', 'were', 'been', 'being', 'am', 'is', 'are', 'had', 'has', 'have', 'having',
  'did', 'does', 'done', 'doing', 'went', 'gone', 'going', 'came', 'coming',
  'saw', 'seen', 'took', 'taken', 'gave', 'given', 'made', 'making', 'knew', 'known',
  'thought', 'brought', 'bought', 'caught', 'taught', 'fought', 'sought',
  'wrote', 'written', 'writing', 'spoke', 'spoken', 'broke', 'broken', 'chose', 'chosen',
  'drove', 'driven', 'driving', 'rode', 'ridden', 'rose', 'risen', 'fell', 'fallen',
  'forgot', 'forgotten', 'forgave', 'forgiven', 'froze', 'frozen', 'stole', 'stolen',
  'wore', 'worn', 'tore', 'torn', 'swore', 'sworn', 'shook', 'shaken', 'threw', 'thrown',
  'grew', 'grown', 'blew', 'blown', 'flew', 'flown', 'drew', 'drawn', 'showed', 'shown',
  'ran', 'running', 'swam', 'swum', 'swimming', 'began', 'begun', 'beginning',
  'sang', 'sung', 'rang', 'rung', 'sank', 'sunk', 'drank', 'drunk',
  'better', 'best', 'worse', 'worst', 'further', 'furthest', 'farther', 'farthest',
  'indices', 'matrices', 'analyses', 'theses', 'criteria', 'phenomena', 'data', 'media',
]);

export function isKnownWord(rawWord: string, customDict: Set<string>): boolean {
  const lower = rawWord.toLowerCase();
  if (!lower || lower.length <= 1) return true;
  if (/^\d+([.,]\d+)?(st|nd|rd|th|%)?$/.test(lower)) return true;
  if (DICTIONARY_SET.has(lower) || IRREGULAR_KNOWN.has(lower) || customDict.has(lower)) {
    return true;
  }

  // Possessives: word's or words'
  if (lower.endsWith("'s") || lower.endsWith("’s")) {
    const base = lower.slice(0, -2);
    if (isKnownWord(base, customDict)) return true;
  }
  if (lower.endsWith("s'") || lower.endsWith("s’")) {
    const base = lower.slice(0, -1);
    if (isKnownWord(base, customDict)) return true;
  }

  // Hyphenated compound words: check each segment
  if (lower.includes('-')) {
    const parts = lower.split('-').filter(Boolean);
    if (parts.length > 1 && parts.every((p) => isKnownWord(p, customDict))) {
      return true;
    }
  }

  // Prefix checks
  const prefixes = ['un', 're', 'pre', 'dis', 'mis', 'non', 'over', 'under', 'sub', 'inter', 'super', 'multi', 'semi', 'anti', 'auto', 'bi', 'co', 'de', 'micro', 'macro', 'post', 'pro', 'trans'];
  for (const pre of prefixes) {
    if (lower.startsWith(pre) && lower.length > pre.length + 2) {
      const rest = lower.slice(pre.length);
      if (DICTIONARY_SET.has(rest)) return true;
    }
  }

  // Common English suffix morphology
  const checkStem = (stem: string): boolean =>
    stem.length >= 2 && (DICTIONARY_SET.has(stem) || DICTIONARY_SET.has(stem + 'e'));

  if (lower.endsWith('s') && !lower.endsWith('ss')) {
    if (DICTIONARY_SET.has(lower.slice(0, -1))) return true;
    if (lower.endsWith('es') && checkStem(lower.slice(0, -2))) return true;
    if (lower.endsWith('ies') && DICTIONARY_SET.has(lower.slice(0, -3) + 'y')) return true;
    if (lower.endsWith('ves') && (DICTIONARY_SET.has(lower.slice(0, -3) + 'f') || DICTIONARY_SET.has(lower.slice(0, -3) + 'fe'))) return true;
  }

  if (lower.endsWith('ed')) {
    const base = lower.slice(0, -2);
    if (checkStem(base)) return true;
    if (lower.endsWith('ied') && DICTIONARY_SET.has(lower.slice(0, -3) + 'y')) return true;
    // doubled consonant e.g. stopped -> stop
    if (base.length >= 3 && base[base.length - 1] === base[base.length - 2] && DICTIONARY_SET.has(base.slice(0, -1))) return true;
  }

  if (lower.endsWith('ing')) {
    const base = lower.slice(0, -3);
    if (checkStem(base)) return true;
    if (lower.endsWith('ying') && DICTIONARY_SET.has(lower.slice(0, -4) + 'ie')) return true;
    if (base.length >= 3 && base[base.length - 1] === base[base.length - 2] && DICTIONARY_SET.has(base.slice(0, -1))) return true;
  }

  if (lower.endsWith('ly')) {
    const base = lower.slice(0, -2);
    if (DICTIONARY_SET.has(base) || DICTIONARY_SET.has(base + 'e') || DICTIONARY_SET.has(base + 'le')) return true;
    if (lower.endsWith('ily') && DICTIONARY_SET.has(lower.slice(0, -3) + 'y')) return true;
    if (lower.endsWith('ally') && DICTIONARY_SET.has(lower.slice(0, -2)) ) return true;
    if (lower.endsWith('ally') && DICTIONARY_SET.has(lower.slice(0, -4))) return true;
  }

  if (lower.endsWith('er') || lower.endsWith('est')) {
    const cut = lower.endsWith('er') ? 2 : 3;
    const base = lower.slice(0, -cut);
    if (checkStem(base)) return true;
    if (lower.endsWith('ier') && DICTIONARY_SET.has(lower.slice(0, -3) + 'y')) return true;
    if (lower.endsWith('iest') && DICTIONARY_SET.has(lower.slice(0, -4) + 'y')) return true;
    if (base.length >= 3 && base[base.length - 1] === base[base.length - 2] && DICTIONARY_SET.has(base.slice(0, -1))) return true;
  }

  const derivSuffixes = ['ment', 'ness', 'tion', 'ation', 'ition', 'sion', 'able', 'ible', 'ful', 'less', 'ous', 'ive', 'al', 'ity', 'ize', 'ise', 'ized', 'ised', 'izing', 'ising', 'ship', 'hood', 'ward', 'wards', 'ers'];
  for (const suf of derivSuffixes) {
    if (lower.endsWith(suf) && lower.length > suf.length + 2) {
      const base = lower.slice(0, -suf.length);
      if (checkStem(base) || DICTIONARY_SET.has(base + 'y')) return true;
      if (suf === 'ation' && (DICTIONARY_SET.has(base + 'ate') || DICTIONARY_SET.has(base))) return true;
      if (suf === 'ity' && (DICTIONARY_SET.has(base + 'e') || DICTIONARY_SET.has(base))) return true;
    }
  }

  return false;
}

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 2) return 3;
  const dp: number[] = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const temp = dp[j];
      if (a[i - 1] === b[j - 1]) {
        dp[j] = prev;
      } else {
        // Check adjacent transposition (Damerau-like)
        dp[j] = 1 + Math.min(prev, dp[j], dp[j - 1]);
      }
      prev = temp;
    }
  }
  return dp[n];
}

function matchCasing(original: string, suggestion: string): string {
  if (original === original.toUpperCase() && original.length > 1) {
    return suggestion.toUpperCase();
  }
  if (original[0] === original[0].toUpperCase()) {
    return suggestion.charAt(0).toUpperCase() + suggestion.slice(1);
  }
  return suggestion;
}

export function getSpellingSuggestions(word: string, maxResults = 4): string[] {
  const lower = word.toLowerCase();
  const direct = COMMON_MISSPELLINGS[lower];
  if (direct && direct.length > 0) {
    return direct.slice(0, maxResults).map((s) => matchCasing(word, s));
  }

  const candidates: Array<{ word: string; dist: number }> = [];
  const firstChar = lower[0];
  for (const dictWord of DICTIONARY_SET) {
    if (Math.abs(dictWord.length - lower.length) > 2) continue;
    // Quick filter: share first or second letter
    if (dictWord[0] !== firstChar && dictWord[1] !== lower[1]) continue;
    const dist = levenshtein(lower, dictWord);
    if (dist <= 2) {
      candidates.push({ word: dictWord, dist });
    }
  }

  candidates.sort((a, b) => {
    if (a.dist !== b.dist) return a.dist - b.dist;
    // Prefer same starting letter
    const aSame = a.word[0] === firstChar ? 0 : 1;
    const bSame = b.word[0] === firstChar ? 0 : 1;
    if (aSame !== bSame) return aSame - bSame;
    return Math.abs(a.word.length - lower.length) - Math.abs(b.word.length - lower.length);
  });

  return candidates.slice(0, maxResults).map((c) => matchCasing(word, c.word));
}
