import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { BackstageModal } from './components/BackstageModal';
import { FindReplaceBar } from './components/FindReplaceBar';
import { OutlineSidebar } from './components/OutlineSidebar';
import { ProofingSidebar } from './components/ProofingSidebar';
import { ActiveFormatState, Ribbon } from './components/Ribbon';
import { Ruler } from './components/Ruler';
import { StatsModal } from './components/StatsModal';
import { StatusBar } from './components/StatusBar';
import { SuggestionPopover } from './components/SuggestionPopover';
import { TitleBar } from './components/TitleBar';
import { DEFAULT_PAGE_SETTINGS } from './data/templates';
import {
  DocumentComment,
  DocumentStats,
  HeadingNode,
  PageMargins,
  PageSettings,
  ProofingIssue,
  RibbonTab,
  StoredDocument,
  TemplatePreset,
} from './types/document';
import { exportToDocx, exportToHtml, exportToPlainText } from './utils/docxExport';
import { importDocumentFile } from './utils/docxImport';
import {
  analyzeDocumentProofing,
  applyIssueReplacement,
  computeDocumentStats,
  extractDocumentHeadings,
} from './utils/proofingEngine';

const RECENT_DOCS_KEY = 'folioword_recent_docs_v1';
const CUSTOM_DICT_KEY = 'folioword_custom_dict_v1';

const PAPER_INCHES = {
  letter: { w: 8.5, h: 11 },
  a4: { w: 8.27, h: 11.69 },
  legal: { w: 8.5, h: 14 },
};

const PX_PER_INCH = 96;

export default function App() {
  const editorRef = useRef<HTMLDivElement>(null);
  const pageSheetRef = useRef<HTMLDivElement>(null);
  const proofingTimerRef = useRef<number | null>(null);
  const savedRangeRef = useRef<Range | null>(null);

  const [docId, setDocId] = useState<string>(() => `doc-${Date.now()}`);
  const [title, setTitle] = useState<string>('Untitled Document');
  const [settings, setSettings] = useState<PageSettings>(DEFAULT_PAGE_SETTINGS);
  const [comments, setComments] = useState<DocumentComment[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const [lastSavedText, setLastSavedText] = useState('Ready');

  // UI Chrome State
  const [activeTab, setActiveTab] = useState<RibbonTab>('home');
  const [ribbonCollapsed, setRibbonCollapsed] = useState(false);
  const [darkWorkspace, setDarkWorkspace] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [showOutline, setShowOutline] = useState(false);
  const [showProofing, setShowProofing] = useState(false);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [showBackstage, setShowBackstage] = useState(false);
  const [showStatsModal, setShowStatsModal] = useState(false);

  // Comment Dialog State
  const [commentDraft, setCommentDraft] = useState<{
    open: boolean;
    quotedText: string;
    body: string;
  }>({ open: false, quotedText: '', body: '' });

  // Proofing State
  const [autoProofing, setAutoProofing] = useState(true);
  const [checkSpelling, setCheckSpelling] = useState(true);
  const [checkGrammar, setCheckGrammar] = useState(true);
  const [checkStyle, setCheckStyle] = useState(true);
  const [issues, setIssues] = useState<ProofingIssue[]>([]);
  const [ignoredTokens, setIgnoredTokens] = useState<Set<string>>(new Set());
  const [customDict, setCustomDict] = useState<Set<string>>(() => {
    try {
      const raw = localStorage.getItem(CUSTOM_DICT_KEY);
      if (raw) return new Set(JSON.parse(raw) as string[]);
    } catch {
      // ignore storage failure
    }
    return new Set();
  });
  const [activePopover, setActivePopover] = useState<{
    issue: ProofingIssue;
    x: number;
    y: number;
  } | null>(null);

  // Document Metrics & Outline
  const [stats, setStats] = useState<DocumentStats>(() => computeDocumentStats(null));
  const [headings, setHeadings] = useState<HeadingNode[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  // Recent Local Docs
  const [recentDocs, setRecentDocs] = useState<StoredDocument[]>(() => {
    try {
      const raw = localStorage.getItem(RECENT_DOCS_KEY);
      if (raw) return JSON.parse(raw) as StoredDocument[];
    } catch {
      // ignore
    }
    return [];
  });

  // Active Toolbar Format State
  const [formatState, setFormatState] = useState<ActiveFormatState>({
    bold: false,
    italic: false,
    underline: false,
    strike: false,
    subscript: false,
    superscript: false,
    align: 'left',
    unorderedList: false,
    orderedList: false,
    blockTag: 'P',
    fontFamily: DEFAULT_PAGE_SETTINGS.defaultFontFamily,
    fontSizePx: Math.round(DEFAULT_PAGE_SETTINGS.defaultFontSizePt / 0.75),
    insideTable: false,
  });

  const showToast = useCallback((msg: string) => {
    setToast(msg);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(t);
  }, [toast]);

  // Sync dark mode class on <html>
  useEffect(() => {
    if (darkWorkspace) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkWorkspace]);

  // Initialize blank page on mount
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML.trim() === '') {
      editorRef.current.innerHTML = '<p><br></p>';
    }
    try {
      document.execCommand('defaultParagraphSeparator', false, 'p');
    } catch {
      // ignore
    }
  }, []);

  // Dimensions in px
  const paperDimIn = useMemo(() => {
    const base = PAPER_INCHES[settings.paperSize];
    return settings.orientation === 'landscape'
      ? { w: base.h, h: base.w }
      : { w: base.w, h: base.h };
  }, [settings.paperSize, settings.orientation]);

  const pageWidthPx = Math.round(paperDimIn.w * PX_PER_INCH);
  const pageMinHeightPx = Math.round(paperDimIn.h * PX_PER_INCH);
  const zoomScale = zoom / 100;

  // CSS Custom Highlights sync
  const supportsCssHighlights =
    typeof CSS !== 'undefined' && 'highlights' in CSS && typeof Highlight !== 'undefined';

  const syncCssHighlights = useCallback(
    (nextIssues: ProofingIssue[]) => {
      if (!supportsCssHighlights) return;
      const registry = (CSS as unknown as { highlights: Map<string, Highlight> }).highlights;
      registry.delete('spelling-error');
      registry.delete('grammar-error');
      registry.delete('style-error');

      if (!autoProofing) return;

      const spellRanges = nextIssues.filter((i) => i.kind === 'spelling').map((i) => i.range);
      const grammarRanges = nextIssues.filter((i) => i.kind === 'grammar').map((i) => i.range);
      const styleRanges = nextIssues.filter((i) => i.kind === 'style').map((i) => i.range);

      if (spellRanges.length > 0) registry.set('spelling-error', new Highlight(...spellRanges));
      if (grammarRanges.length > 0) registry.set('grammar-error', new Highlight(...grammarRanges));
      if (styleRanges.length > 0) registry.set('style-error', new Highlight(...styleRanges));
    },
    [autoProofing, supportsCssHighlights]
  );

  const runAnalysisNow = useCallback(() => {
    const el = editorRef.current;
    if (!el) return;

    setStats(computeDocumentStats(el));
    setHeadings(extractDocumentHeadings(el));

    if (!autoProofing) {
      setIssues([]);
      syncCssHighlights([]);
      return;
    }

    const found = analyzeDocumentProofing(el, customDict, ignoredTokens, zoomScale, {
      checkSpelling,
      checkGrammar,
      checkStyle,
    });
    setIssues(found);
    syncCssHighlights(found);
  }, [
    autoProofing,
    checkGrammar,
    checkSpelling,
    checkStyle,
    customDict,
    ignoredTokens,
    syncCssHighlights,
    zoomScale,
  ]);

  const scheduleAnalysis = useCallback(() => {
    if (proofingTimerRef.current) {
      window.clearTimeout(proofingTimerRef.current);
    }
    proofingTimerRef.current = window.setTimeout(() => {
      runAnalysisNow();
    }, 280);
  }, [runAnalysisNow]);

  useEffect(() => {
    runAnalysisNow();
  }, [runAnalysisNow]);

  // Refresh active selection formatting state
  const updateFormatState = useCallback(() => {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || !editorRef.current) return;
    const anchor = sel.anchorNode;
    if (!anchor || !editorRef.current.contains(anchor)) return;

    savedRangeRef.current = sel.getRangeAt(0).cloneRange();

    let node: Node | null = anchor;
    let blockTag = 'P';
    let insideTable = false;
    while (node && node !== editorRef.current) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const tag = (node as HTMLElement).tagName;
        if (['TD', 'TH', 'TABLE'].includes(tag)) insideTable = true;
        if (['H1', 'H2', 'H3', 'BLOCKQUOTE', 'P', 'LI'].includes(tag) && blockTag === 'P') {
          blockTag = tag;
        }
      }
      node = node.parentNode;
    }

    const anchorEl =
      anchor.nodeType === Node.ELEMENT_NODE
        ? (anchor as HTMLElement)
        : anchor.parentElement;
    const computed = anchorEl ? window.getComputedStyle(anchorEl) : null;

    let align: ActiveFormatState['align'] = 'left';
    if (document.queryCommandState('justifyCenter')) align = 'center';
    else if (document.queryCommandState('justifyRight')) align = 'right';
    else if (document.queryCommandState('justifyFull')) align = 'justify';

    setFormatState({
      bold: document.queryCommandState('bold'),
      italic: document.queryCommandState('italic'),
      underline: document.queryCommandState('underline'),
      strike: document.queryCommandState('strikeThrough'),
      subscript: document.queryCommandState('subscript'),
      superscript: document.queryCommandState('superscript'),
      align,
      unorderedList: document.queryCommandState('insertUnorderedList'),
      orderedList: document.queryCommandState('insertOrderedList'),
      blockTag,
      fontFamily: computed?.fontFamily || settings.defaultFontFamily,
      fontSizePx: computed ? parseFloat(computed.fontSize) : 15,
      insideTable,
    });
  }, [settings.defaultFontFamily]);

  const restoreSelection = useCallback(() => {
    const sel = window.getSelection();
    if (sel && savedRangeRef.current && editorRef.current?.contains(savedRangeRef.current.startContainer)) {
      sel.removeAllRanges();
      sel.addRange(savedRangeRef.current);
    } else {
      editorRef.current?.focus();
    }
  }, []);

  const handleEditorInput = useCallback(() => {
    setIsDirty(true);
    setActivePopover(null);
    scheduleAnalysis();
    updateFormatState();
  }, [scheduleAnalysis, updateFormatState]);

  const execCommand = useCallback(
    (cmd: string, value?: string) => {
      editorRef.current?.focus();
      document.execCommand(cmd, false, value);
      handleEditorInput();
    },
    [handleEditorInput]
  );

  const applyFontFamily = useCallback(
    (font: string) => {
      restoreSelection();
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed) {
        setSettings((prev) => ({ ...prev, defaultFontFamily: font }));
        showToast('Updated document default font');
      } else {
        document.execCommand('fontName', false, font);
        handleEditorInput();
      }
    },
    [handleEditorInput, restoreSelection, showToast]
  );

  const applyFontSizePt = useCallback(
    (pt: number) => {
      restoreSelection();
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed) {
        setSettings((prev) => ({ ...prev, defaultFontSizePt: pt }));
        showToast(`Updated base font size to ${pt}pt`);
        return;
      }
      // Wrap selected range in a clean span with exact pt size
      const range = sel.getRangeAt(0);
      const span = document.createElement('span');
      span.style.fontSize = `${pt}pt`;
      try {
        const contents = range.extractContents();
        span.appendChild(contents);
        range.insertNode(span);
        sel.removeAllRanges();
        const nextRange = document.createRange();
        nextRange.selectNodeContents(span);
        sel.addRange(nextRange);
        savedRangeRef.current = nextRange.cloneRange();
        handleEditorInput();
      } catch {
        document.execCommand('fontSize', false, '4');
        handleEditorInput();
      }
    },
    [handleEditorInput, restoreSelection, showToast]
  );

  const applyBlockStyle = useCallback(
    (tag: 'P' | 'H1' | 'H2' | 'H3' | 'BLOCKQUOTE') => {
      editorRef.current?.focus();
      document.execCommand('formatBlock', false, tag);
      handleEditorInput();
    },
    [handleEditorInput]
  );

  const handleClearFormatting = useCallback(() => {
    editorRef.current?.focus();
    document.execCommand('removeFormat');
    document.execCommand('formatBlock', false, 'P');
    handleEditorInput();
  }, [handleEditorInput]);

  const handleClipboardAction = useCallback(
    async (action: 'cut' | 'copy' | 'paste') => {
      editorRef.current?.focus();
      if (action === 'paste') {
        try {
          const text = await navigator.clipboard.readText();
          if (text) {
            document.execCommand('insertText', false, text);
            handleEditorInput();
          }
        } catch {
          showToast('Use Ctrl+V / Cmd+V to paste from your clipboard');
        }
        return;
      }
      document.execCommand(action);
      handleEditorInput();
    },
    [handleEditorInput, showToast]
  );

  // Insert Helpers
  const insertTable = useCallback(
    (rows: number, cols: number) => {
      restoreSelection();
      let html = '<table><thead><tr>';
      for (let c = 0; c < cols; c++) html += `<th>Header ${c + 1}</th>`;
      html += '</tr></thead><tbody>';
      for (let r = 1; r < rows; r++) {
        html += '<tr>';
        for (let c = 0; c < cols; c++) html += '<td>&nbsp;</td>';
        html += '</tr>';
      }
      html += '</tbody></table><p><br></p>';
      document.execCommand('insertHTML', false, html);
      handleEditorInput();
    },
    [handleEditorInput, restoreSelection]
  );

  const handleTableAction = useCallback(
    (action: 'addRow' | 'addCol' | 'delRow' | 'delCol' | 'delTable') => {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      let node: Node | null = sel.anchorNode;
      let cell: HTMLTableCellElement | null = null;
      let row: HTMLTableRowElement | null = null;
      let table: HTMLTableElement | null = null;

      while (node && node !== editorRef.current) {
        if (node instanceof HTMLTableCellElement && !cell) cell = node;
        if (node instanceof HTMLTableRowElement && !row) row = node;
        if (node instanceof HTMLTableElement && !table) {
          table = node;
          break;
        }
        node = node.parentNode;
      }
      if (!table || !row || !cell) return;

      const cellIndex = cell.cellIndex;
      if (action === 'addRow') {
        const newRow = table.insertRow(row.rowIndex + 1);
        for (let i = 0; i < row.cells.length; i++) {
          const td = newRow.insertCell();
          td.innerHTML = '&nbsp;';
        }
      } else if (action === 'delRow') {
        if (table.rows.length <= 1) table.remove();
        else table.deleteRow(row.rowIndex);
      } else if (action === 'addCol') {
        Array.from(table.rows).forEach((r, idx) => {
          const newCell =
            idx === 0 && r.cells[0]?.tagName === 'TH'
              ? document.createElement('th')
              : document.createElement('td');
          newCell.innerHTML = idx === 0 && newCell.tagName === 'TH' ? 'Column' : '&nbsp;';
          if (cellIndex + 1 < r.cells.length) {
            r.insertBefore(newCell, r.cells[cellIndex + 1]);
          } else {
            r.appendChild(newCell);
          }
        });
      } else if (action === 'delCol') {
        if (row.cells.length <= 1) {
          table.remove();
        } else {
          Array.from(table.rows).forEach((r) => {
            if (r.cells[cellIndex]) r.deleteCell(cellIndex);
          });
        }
      } else if (action === 'delTable') {
        table.remove();
      }
      handleEditorInput();
    },
    [handleEditorInput]
  );

  const insertImageFile = useCallback(
    (file: File) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          restoreSelection();
          document.execCommand(
            'insertHTML',
            false,
            `<p><img src="${reader.result}" alt="${file.name}" style="max-width: 100%; height: auto;" /></p>`
          );
          handleEditorInput();
        }
      };
      reader.readAsDataURL(file);
    },
    [handleEditorInput, restoreSelection]
  );

  const insertImageUrl = useCallback(
    (url: string) => {
      restoreSelection();
      document.execCommand(
        'insertHTML',
        false,
        `<p><img src="${url}" alt="Inserted image" style="max-width: 100%; height: auto;" /></p>`
      );
      handleEditorInput();
    },
    [handleEditorInput, restoreSelection]
  );

  const insertLink = useCallback(
    (url: string, label?: string) => {
      restoreSelection();
      const sel = window.getSelection();
      const selectedText = sel && !sel.isCollapsed ? sel.toString() : '';
      const text = label || selectedText || url;
      document.execCommand(
        'insertHTML',
        false,
        `<a href="${url}" target="_blank" rel="noopener noreferrer">${text}</a>`
      );
      handleEditorInput();
    },
    [handleEditorInput, restoreSelection]
  );

  const insertPageBreak = useCallback(() => {
    restoreSelection();
    document.execCommand(
      'insertHTML',
      false,
      '<div class="folio-page-break" contenteditable="false">— Page Break —</div><p><br></p>'
    );
    handleEditorInput();
  }, [handleEditorInput, restoreSelection]);

  const insertHorizontalRule = useCallback(() => {
    restoreSelection();
    document.execCommand('insertHorizontalRule');
    handleEditorInput();
  }, [handleEditorInput, restoreSelection]);

  const insertCurrentDate = useCallback(() => {
    restoreSelection();
    const formatted = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    document.execCommand('insertText', false, formatted);
    handleEditorInput();
  }, [handleEditorInput, restoreSelection]);

  // Save & Load Local Persistence
  const saveToLocal = useCallback(() => {
    const html = editorRef.current?.innerHTML || '<p><br></p>';
    const currentStats = computeDocumentStats(editorRef.current);
    const nowLabel = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const record: StoredDocument = {
      id: docId,
      title: title || 'Untitled Document',
      html,
      settings,
      comments,
      updatedAt: `${new Date().toLocaleDateString()} ${nowLabel}`,
      wordCount: currentStats.words,
    };

    setRecentDocs((prev) => {
      const next = [record, ...prev.filter((d) => d.id !== docId)].slice(0, 12);
      try {
        localStorage.setItem(RECENT_DOCS_KEY, JSON.stringify(next));
      } catch {
        // ignore storage quota
      }
      return next;
    });

    setIsDirty(false);
    setLastSavedText(`Saved ${nowLabel}`);
    showToast('Document saved locally');
  }, [comments, docId, settings, showToast, title]);

  const loadTemplate = useCallback(
    (tpl: TemplatePreset) => {
      const nextSettings: PageSettings = {
        ...DEFAULT_PAGE_SETTINGS,
        ...tpl.settings,
        margins: {
          ...DEFAULT_PAGE_SETTINGS.margins,
          ...(tpl.settings.margins || {}),
        },
      };
      setDocId(`doc-${Date.now()}`);
      setTitle(tpl.defaultTitle);
      setSettings(nextSettings);
      setComments([]);
      setIgnoredTokens(new Set());
      if (editorRef.current) {
        editorRef.current.innerHTML = tpl.html;
      }
      setIsDirty(false);
      setLastSavedText('Template loaded');
      setActivePopover(null);
      window.setTimeout(() => runAnalysisNow(), 50);
    },
    [runAnalysisNow]
  );

  const openStoredDoc = useCallback(
    (doc: StoredDocument) => {
      setDocId(doc.id);
      setTitle(doc.title);
      setSettings(doc.settings);
      setComments(doc.comments || []);
      setIgnoredTokens(new Set());
      if (editorRef.current) {
        editorRef.current.innerHTML = doc.html;
      }
      setIsDirty(false);
      setLastSavedText(`Opened · ${doc.updatedAt}`);
      setActivePopover(null);
      window.setTimeout(() => runAnalysisNow(), 50);
    },
    [runAnalysisNow]
  );

  const deleteRecentDoc = useCallback((id: string) => {
    setRecentDocs((prev) => {
      const next = prev.filter((d) => d.id !== id);
      try {
        localStorage.setItem(RECENT_DOCS_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const handleImportFile = useCallback(
    async (file: File) => {
      try {
        const imported = await importDocumentFile(file);
        setDocId(`doc-${Date.now()}`);
        setTitle(imported.title);
        setComments([]);
        setIgnoredTokens(new Set());
        if (editorRef.current) {
          editorRef.current.innerHTML = imported.html;
        }
        setIsDirty(false);
        setLastSavedText('Imported');
        showToast(`Opened "${file.name}"`);
        window.setTimeout(() => runAnalysisNow(), 60);
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Unable to open file');
      }
    },
    [runAnalysisNow, showToast]
  );

  const handleExportDocx = useCallback(async () => {
    try {
      const html = editorRef.current?.innerHTML || '<p></p>';
      await exportToDocx(title, html, settings);
      showToast(`Exported "${title || 'Document'}.docx"`);
    } catch {
      showToast('Failed to export .docx file');
    }
  }, [settings, showToast, title]);

  const handleExportHtml = useCallback(() => {
    const html = editorRef.current?.innerHTML || '<p></p>';
    exportToHtml(title, html, settings);
    showToast(`Exported "${title || 'Document'}.html"`);
  }, [settings, showToast, title]);

  const handleExportTxt = useCallback(() => {
    const txt = editorRef.current?.innerText || '';
    exportToPlainText(title, txt);
    showToast(`Exported "${title || 'Document'}.txt"`);
  }, [showToast, title]);

  // Proofing Actions
  const handleApplySuggestion = useCallback(
    (issue: ProofingIssue, replacement: string) => {
      const ok = applyIssueReplacement(issue, replacement);
      if (ok) {
        setActivePopover(null);
        setIsDirty(true);
        runAnalysisNow();
      }
    },
    [runAnalysisNow]
  );

  const handleIgnoreIssue = useCallback((issue: ProofingIssue) => {
    setIgnoredTokens((prev) => {
      const next = new Set(prev);
      next.add(issue.wordOrPhrase.toLowerCase());
      return next;
    });
    setActivePopover(null);
  }, []);

  const handleAddToDictionary = useCallback(
    (word: string) => {
      const clean = word.toLowerCase();
      setCustomDict((prev) => {
        const next = new Set(prev);
        next.add(clean);
        try {
          localStorage.setItem(CUSTOM_DICT_KEY, JSON.stringify(Array.from(next)));
        } catch {
          // ignore
        }
        return next;
      });
      setActivePopover(null);
      showToast(`Added "${word}" to dictionary`);
    },
    [showToast]
  );

  const handleJumpToIssue = useCallback((issue: ProofingIssue) => {
    const sel = window.getSelection();
    if (sel) {
      sel.removeAllRanges();
      sel.addRange(issue.range);
    }
    const rect = issue.range.getBoundingClientRect();
    setActivePopover({
      issue,
      x: rect.left,
      y: rect.bottom + 6,
    });
  }, []);

  // Detect clicks on underlined words in editor to open SuggestionPopover
  const handleEditorClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      updateFormatState();
      if (!autoProofing || issues.length === 0 || !editorRef.current) {
        setActivePopover(null);
        return;
      }

      const containerRect = editorRef.current.getBoundingClientRect();
      const relX = (e.clientX - containerRect.left) / zoomScale;
      const relY = (e.clientY - containerRect.top) / zoomScale;

      const hit = issues.find((issue) =>
        issue.rects.some(
          (r) =>
            relX >= r.left - 2 &&
            relX <= r.left + r.width + 2 &&
            relY >= r.top - 2 &&
            relY <= r.top + r.height + 4
        )
      );

      if (hit) {
        const rect = hit.range.getBoundingClientRect();
        setActivePopover({
          issue: hit,
          x: rect.left,
          y: rect.bottom + 6,
        });
      } else {
        setActivePopover(null);
      }
    },
    [autoProofing, issues, updateFormatState, zoomScale]
  );

  // Find & Replace
  const handleFindNext = useCallback((query: string, matchCase: boolean): number => {
    if (!editorRef.current || !query) return 0;
    const text = editorRef.current.innerText || '';
    const haystack = matchCase ? text : text.toLowerCase();
    const needle = matchCase ? query : query.toLowerCase();
    let count = 0;
    let idx = haystack.indexOf(needle);
    while (idx !== -1) {
      count++;
      idx = haystack.indexOf(needle, idx + needle.length);
    }
    // Native window.find highlights next occurrence seamlessly inside contentEditable
    const win = window as unknown as {
      find?: (
        str: string,
        caseSensitive?: boolean,
        backwards?: boolean,
        wrapAround?: boolean
      ) => boolean;
    };
    if (win.find) {
      win.find(query, matchCase, false, true);
    }
    return count;
  }, []);

  const handleReplaceOne = useCallback(
    (query: string, replacement: string, matchCase: boolean) => {
      if (!query || !editorRef.current) return;
      const sel = window.getSelection();
      const current = sel?.toString() || '';
      const matchesSelected = matchCase
        ? current === query
        : current.toLowerCase() === query.toLowerCase();

      if (matchesSelected && sel && sel.rangeCount > 0) {
        document.execCommand('insertText', false, replacement);
        handleEditorInput();
      }
      handleFindNext(query, matchCase);
    },
    [handleEditorInput, handleFindNext]
  );

  const handleReplaceAll = useCallback(
    (query: string, replacement: string, matchCase: boolean): number => {
      if (!query || !editorRef.current) return 0;
      const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(escaped, matchCase ? 'g' : 'gi');
      let replacements = 0;

      const walker = document.createTreeWalker(editorRef.current, NodeFilter.SHOW_TEXT);
      const textNodes: Text[] = [];
      let n = walker.nextNode();
      while (n) {
        textNodes.push(n as Text);
        n = walker.nextNode();
      }

      for (const node of textNodes) {
        const val = node.nodeValue || '';
        const updated = val.replace(regex, () => {
          replacements++;
          return replacement;
        });
        if (updated !== val) {
          node.nodeValue = updated;
        }
      }

      if (replacements > 0) {
        handleEditorInput();
      }
      return replacements;
    },
    [handleEditorInput]
  );

  // Jump to Heading
  const handleJumpToHeading = useCallback((elementIndex: number) => {
    if (!editorRef.current) return;
    const headingEls = editorRef.current.querySelectorAll('h1, h2, h3');
    const target = headingEls[elementIndex];
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, []);

  // Add Comment
  const handleOpenCommentDialog = useCallback(() => {
    const sel = window.getSelection();
    const quoted = sel ? sel.toString().trim() : '';
    setCommentDraft({ open: true, quotedText: quoted, body: '' });
  }, []);

  const handleSubmitComment = useCallback(() => {
    if (!commentDraft.body.trim()) return;
    const newComment: DocumentComment = {
      id: `cmt-${Date.now()}`,
      quotedText: commentDraft.quotedText,
      body: commentDraft.body.trim(),
      author: 'Reviewer',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      resolved: false,
    };
    setComments((prev) => [newComment, ...prev]);
    setCommentDraft({ open: false, quotedText: '', body: '' });
    setShowProofing(true);
    setIsDirty(true);
  }, [commentDraft]);

  // Global keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;

      if (e.key.toLowerCase() === 's') {
        e.preventDefault();
        saveToLocal();
      } else if (e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setShowFindReplace((v) => !v);
      } else if (e.key.toLowerCase() === 'p') {
        e.preventDefault();
        window.print();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [saveToLocal]);

  // Tab key inside editor
  const handleEditorKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        document.execCommand('insertHTML', false, '&nbsp;&nbsp;&nbsp;&nbsp;');
        handleEditorInput();
      }
    },
    [handleEditorInput]
  );

  const pageToneBg =
    settings.pageTone === 'ivory'
      ? '#FFFDF7'
      : settings.pageTone === 'cool'
      ? '#F8FAFC'
      : '#FFFFFF';

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Top Windows Title Bar */}
      {!focusMode && (
        <TitleBar
          title={title}
          onTitleChange={(next) => {
            setTitle(next);
            setIsDirty(true);
          }}
          isDirty={isDirty}
          lastSavedText={lastSavedText}
          darkWorkspace={darkWorkspace}
          onToggleDarkWorkspace={() => setDarkWorkspace((d) => !d)}
          onUndo={() => execCommand('undo')}
          onRedo={() => execCommand('redo')}
          onSaveLocal={saveToLocal}
          onExportDocx={handleExportDocx}
          onPrint={() => window.print()}
          onOpenBackstage={() => setShowBackstage(true)}
        />
      )}

      {/* Wide Tabbed Ribbon */}
      {!focusMode && (
        <Ribbon
          activeTab={activeTab}
          onTabChange={setActiveTab}
          collapsed={ribbonCollapsed}
          onToggleCollapse={() => setRibbonCollapsed((c) => !c)}
          formatState={formatState}
          settings={settings}
          autoProofing={autoProofing}
          checkSpelling={checkSpelling}
          checkGrammar={checkGrammar}
          checkStyle={checkStyle}
          showOutline={showOutline}
          showProofing={showProofing}
          showFindReplace={showFindReplace}
          darkWorkspace={darkWorkspace}
          issueCount={issues.length}
          zoom={zoom}
          onExecCommand={execCommand}
          onApplyFontFamily={applyFontFamily}
          onApplyFontSizePt={applyFontSizePt}
          onApplyBlockStyle={applyBlockStyle}
          onClearFormatting={handleClearFormatting}
          onInsertTable={insertTable}
          onTableAction={handleTableAction}
          onInsertImageFile={insertImageFile}
          onInsertImageUrl={insertImageUrl}
          onInsertLink={insertLink}
          onInsertPageBreak={insertPageBreak}
          onInsertHorizontalRule={insertHorizontalRule}
          onInsertCurrentDate={insertCurrentDate}
          onUpdateSettings={(patch) => {
            setSettings((prev) => ({ ...prev, ...patch }));
            setIsDirty(true);
          }}
          onSetMargins={(margins: PageMargins) => {
            setSettings((prev) => ({ ...prev, margins }));
            setIsDirty(true);
          }}
          onToggleAutoProofing={() => setAutoProofing((v) => !v)}
          onToggleCheckSpelling={() => setCheckSpelling((v) => !v)}
          onToggleCheckGrammar={() => setCheckGrammar((v) => !v)}
          onToggleCheckStyle={() => setCheckStyle((v) => !v)}
          onToggleOutline={() => setShowOutline((v) => !v)}
          onToggleProofing={() => setShowProofing((v) => !v)}
          onToggleFindReplace={() => setShowFindReplace((v) => !v)}
          onToggleDarkWorkspace={() => setDarkWorkspace((d) => !d)}
          onAddComment={handleOpenCommentDialog}
          onOpenStatsModal={() => setShowStatsModal(true)}
          onZoomChange={setZoom}
          onToggleFocusMode={() => setFocusMode((f) => !f)}
          onOpenBackstage={() => setShowBackstage(true)}
          onClipboardAction={handleClipboardAction}
        />
      )}

      {/* Horizontal Margin Ruler */}
      {!focusMode && settings.showRuler && (
        <Ruler
          pageWidthPx={pageWidthPx}
          pageWidthInches={paperDimIn.w}
          leftMarginIn={settings.margins.left}
          rightMarginIn={settings.margins.right}
          zoomScale={zoomScale}
          onMarginsChange={(left, right) => {
            setSettings((prev) => ({
              ...prev,
              margins: { ...prev.margins, left, right },
            }));
            setIsDirty(true);
          }}
        />
      )}

      {/* Main Desktop Workspace */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        {/* Left Navigation Outline Pane */}
        {!focusMode && showOutline && (
          <OutlineSidebar
            headings={headings}
            settings={settings}
            onJumpToHeading={handleJumpToHeading}
            onClose={() => setShowOutline(false)}
          />
        )}

        {/* Center Document Desk & Blank Digital Page */}
        <main
          className="print-canvas-wrapper flex-1 overflow-auto desktop-scroll bg-slate-200/75 dark:bg-slate-950 p-6 md:p-10 flex justify-center items-start"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) {
              setActivePopover(null);
            }
          }}
        >
          {/* Scaled Page Wrapper so scrolling respects zoom cleanly */}
          <div
            style={{
              width: `${pageWidthPx * zoomScale}px`,
              minHeight: `${pageMinHeightPx * zoomScale}px`,
            }}
            className="shrink-0"
          >
            <div
              ref={pageSheetRef}
              className="print-page-sheet origin-top-left shadow-md border border-slate-300/80 dark:border-slate-700 transition-colors"
              style={{
                width: `${pageWidthPx}px`,
                minHeight: `${pageMinHeightPx}px`,
                transform: `scale(${zoomScale})`,
                backgroundColor: pageToneBg,
                paddingTop: `${settings.margins.top * PX_PER_INCH}px`,
                paddingBottom: `${settings.margins.bottom * PX_PER_INCH}px`,
                paddingLeft: `${settings.margins.left * PX_PER_INCH}px`,
                paddingRight: `${settings.margins.right * PX_PER_INCH}px`,
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              {/* Optional Editable Page Header */}
              {settings.showHeaderFooter && (
                <input
                  type="text"
                  value={settings.headerText}
                  onChange={(e) => {
                    setSettings((prev) => ({ ...prev, headerText: e.target.value }));
                    setIsDirty(true);
                  }}
                  placeholder="Document Header (optional)"
                  aria-label="Document Header"
                  className="w-full text-right text-[11px] text-slate-400 bg-transparent border-b border-dashed border-slate-200 pb-1.5 mb-4 outline-none focus:text-slate-600 focus:border-blue-400"
                />
              )}

              {/* Editable Rich Text Canvas + Fallback Wavy Underline Layer */}
              <div className="relative flex-1">
                {/* Fallback wavy underline overlay when CSS.highlights is unavailable */}
                {!supportsCssHighlights && autoProofing && issues.length > 0 && (
                  <div
                    className="no-print absolute inset-0 pointer-events-none overflow-hidden"
                    aria-hidden="true"
                  >
                    {issues.map((issue) =>
                      issue.rects.map((r, idx) => (
                        <div
                          key={`${issue.id}-${idx}`}
                          style={{
                            position: 'absolute',
                            left: `${r.left}px`,
                            top: `${r.top + r.height - 2}px`,
                            width: `${r.width}px`,
                            height: '3px',
                            borderBottom:
                              issue.kind === 'spelling'
                                ? '2px wavy #dc2626'
                                : issue.kind === 'grammar'
                                ? '2px wavy #2563eb'
                                : '2px dotted #d97706',
                          }}
                        />
                      ))
                    )}
                  </div>
                )}

                <div
                  ref={editorRef}
                  contentEditable
                  suppressContentEditableWarning
                  spellCheck={!autoProofing}
                  onInput={handleEditorInput}
                  onClick={handleEditorClick}
                  onKeyUp={updateFormatState}
                  onMouseUp={updateFormatState}
                  onKeyDown={handleEditorKeyDown}
                  data-placeholder="Start typing your essay, memo, or report…"
                  className="folio-editor min-h-full"
                  style={{
                    fontFamily: settings.defaultFontFamily,
                    fontSize: `${settings.defaultFontSizePt}pt`,
                    lineHeight: settings.lineHeight,
                    columnCount: settings.columns,
                    columnGap: settings.columns > 1 ? '0.4in' : undefined,
                    ['--para-spacing-after' as string]: `${settings.paragraphSpacingAfter}em`,
                  }}
                />
              </div>

              {/* Optional Editable Page Footer */}
              {settings.showHeaderFooter && (
                <input
                  type="text"
                  value={settings.footerText}
                  onChange={(e) => {
                    setSettings((prev) => ({ ...prev, footerText: e.target.value }));
                    setIsDirty(true);
                  }}
                  placeholder="Document Footer (optional)"
                  aria-label="Document Footer"
                  className="w-full text-center text-[11px] text-slate-400 bg-transparent border-t border-dashed border-slate-200 pt-1.5 mt-4 outline-none focus:text-slate-600 focus:border-blue-400"
                />
              )}
            </div>
          </div>
        </main>

        {/* Right Proofing & Comments Sidebar */}
        {!focusMode && showProofing && (
          <ProofingSidebar
            issues={issues}
            comments={comments}
            autoProofing={autoProofing}
            onApplyReplacement={handleApplySuggestion}
            onIgnoreIssue={handleIgnoreIssue}
            onAddToDictionary={handleAddToDictionary}
            onSelectIssue={handleJumpToIssue}
            onResolveComment={(id) =>
              setComments((prev) =>
                prev.map((c) => (c.id === id ? { ...c, resolved: !c.resolved } : c))
              )
            }
            onDeleteComment={(id) =>
              setComments((prev) => prev.filter((c) => c.id !== id))
            }
            onClose={() => setShowProofing(false)}
          />
        )}

        {/* Find & Replace Floating Panel */}
        {showFindReplace && (
          <FindReplaceBar
            onFindNext={handleFindNext}
            onReplaceOne={handleReplaceOne}
            onReplaceAll={handleReplaceAll}
            onClose={() => setShowFindReplace(false)}
          />
        )}
      </div>

      {/* Bottom Status Bar */}
      <StatusBar
        stats={stats}
        issues={issues}
        autoProofing={autoProofing}
        zoom={zoom}
        focusMode={focusMode}
        onZoomChange={setZoom}
        onToggleFocusMode={() => setFocusMode((f) => !f)}
        onOpenProofing={() => {
          setFocusMode(false);
          setShowProofing(true);
        }}
        onOpenStatsModal={() => setShowStatsModal(true)}
      />

      {/* Inline Click-to-Fix Suggestion Popover */}
      {activePopover && (
        <SuggestionPopover
          issue={activePopover.issue}
          position={{ x: activePopover.x, y: activePopover.y }}
          onApply={handleApplySuggestion}
          onIgnore={handleIgnoreIssue}
          onAddToDictionary={handleAddToDictionary}
          onClose={() => setActivePopover(null)}
        />
      )}

      {/* Windows File Backstage View */}
      {showBackstage && (
        <BackstageModal
          currentDocTitle={title}
          recentDocs={recentDocs}
          onClose={() => setShowBackstage(false)}
          onSelectTemplate={loadTemplate}
          onOpenRecentDoc={openStoredDoc}
          onDeleteRecentDoc={deleteRecentDoc}
          onImportFile={handleImportFile}
          onExportDocx={handleExportDocx}
          onExportHtml={handleExportHtml}
          onExportTxt={handleExportTxt}
          onPrint={() => window.print()}
        />
      )}

      {/* Word Count & Readability Dialog */}
      {showStatsModal && (
        <StatsModal stats={stats} onClose={() => setShowStatsModal(false)} />
      )}

      {/* New Comment Modal */}
      {commentDraft.open && (
        <div
          className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
          onClick={() => setCommentDraft({ open: false, quotedText: '', body: '' })}
        >
          <div
            className="w-full max-w-sm rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl p-4 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Add Margin Comment
              </h3>
              <button
                type="button"
                onClick={() => setCommentDraft({ open: false, quotedText: '', body: '' })}
                className="p-1 rounded text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {commentDraft.quotedText && (
              <div className="text-xs italic text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 rounded line-clamp-2">
                “{commentDraft.quotedText}”
              </div>
            )}

            <textarea
              rows={3}
              autoFocus
              value={commentDraft.body}
              onChange={(e) =>
                setCommentDraft((prev) => ({ ...prev, body: e.target.value }))
              }
              placeholder="Write your review note…"
              className="w-full px-3 py-2 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
            />

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCommentDraft({ open: false, quotedText: '', body: '' })}
                className="px-3 py-1.5 text-xs rounded text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmitComment}
                className="px-3 py-1.5 text-xs font-medium rounded bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
              >
                Post Comment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Non-intrusive Notification Toast */}
      {toast && (
        <div
          role="status"
          className="no-print fixed bottom-10 right-4 z-50 px-3.5 py-2 rounded-md bg-slate-900 text-white dark:bg-slate-800 border border-slate-700 text-xs font-medium shadow-lg"
        >
          {toast}
        </div>
      )}
    </div>
  );
}
