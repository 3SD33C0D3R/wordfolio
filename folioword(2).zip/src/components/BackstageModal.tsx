import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  Clock,
  Download,
  FileCode2,
  FilePlus2,
  FileText,
  FolderOpen,
  Printer,
  Trash2,
} from 'lucide-react';
import { DOCUMENT_TEMPLATES } from '../data/templates';
import { StoredDocument, TemplatePreset } from '../types/document';

interface BackstageModalProps {
  currentDocTitle: string;
  recentDocs: StoredDocument[];
  onClose: () => void;
  onSelectTemplate: (template: TemplatePreset) => void;
  onOpenRecentDoc: (doc: StoredDocument) => void;
  onDeleteRecentDoc: (id: string) => void;
  onImportFile: (file: File) => void;
  onExportDocx: () => void;
  onExportHtml: () => void;
  onExportTxt: () => void;
  onPrint: () => void;
}

export const BackstageModal: React.FC<BackstageModalProps> = ({
  currentDocTitle,
  recentDocs,
  onClose,
  onSelectTemplate,
  onOpenRecentDoc,
  onDeleteRecentDoc,
  onImportFile,
  onExportDocx,
  onExportHtml,
  onExportTxt,
  onPrint,
}) => {
  const [section, setSection] = useState<'new' | 'open' | 'export'>('new');
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="no-print fixed inset-0 z-50 flex bg-slate-900/50 backdrop-blur-[1px]">
      <div className="flex w-full h-full bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100">
        {/* Left Cobalt Windows Backstage Sidebar */}
        <div className="w-56 shrink-0 bg-blue-700 text-white flex flex-col justify-between p-4">
          <div className="space-y-6">
            <button
              type="button"
              onClick={onClose}
              className="flex items-center gap-2 text-sm font-medium text-blue-100 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Document</span>
            </button>

            <nav className="flex flex-col gap-1" aria-label="File Menu">
              <button
                type="button"
                onClick={() => setSection('new')}
                className={`flex items-center gap-2.5 px-3 py-2 rounded text-sm font-medium text-left transition-colors cursor-pointer ${
                  section === 'new' ? 'bg-blue-800 text-white' : 'text-blue-100 hover:bg-blue-600'
                }`}
              >
                <FilePlus2 className="w-4 h-4" />
                <span>New &amp; Templates</span>
              </button>

              <button
                type="button"
                onClick={() => setSection('open')}
                className={`flex items-center gap-2.5 px-3 py-2 rounded text-sm font-medium text-left transition-colors cursor-pointer ${
                  section === 'open' ? 'bg-blue-800 text-white' : 'text-blue-100 hover:bg-blue-600'
                }`}
              >
                <FolderOpen className="w-4 h-4" />
                <span>Open &amp; Recent</span>
              </button>

              <button
                type="button"
                onClick={() => setSection('export')}
                className={`flex items-center gap-2.5 px-3 py-2 rounded text-sm font-medium text-left transition-colors cursor-pointer ${
                  section === 'export' ? 'bg-blue-800 text-white' : 'text-blue-100 hover:bg-blue-600'
                }`}
              >
                <Download className="w-4 h-4" />
                <span>Save As &amp; Print</span>
              </button>
            </nav>
          </div>

          <div className="text-xs text-blue-200 border-t border-blue-600 pt-3">
            <div className="font-medium text-white truncate">{currentDocTitle}</div>
            <div className="mt-0.5 text-[11px] opacity-80">FolioWord Desktop</div>
          </div>
        </div>

        {/* Main Content Pane */}
        <div className="flex-1 overflow-y-auto desktop-scroll p-8 md:p-12 bg-slate-50 dark:bg-slate-950">
          <div className="max-w-4xl mx-auto">
            {section === 'new' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    Create a Document
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    Begin with a blank digital page or choose a pre-formatted layout for academic
                    and corporate writing.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {DOCUMENT_TEMPLATES.map((tpl) => (
                    <button
                      key={tpl.id}
                      type="button"
                      onClick={() => {
                        onSelectTemplate(tpl);
                        onClose();
                      }}
                      className="text-left p-5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-colors cursor-pointer flex flex-col justify-between gap-4"
                    >
                      <div className="space-y-1.5">
                        <div className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                          {tpl.category}
                        </div>
                        <div className="text-base font-semibold text-slate-900 dark:text-white">
                          {tpl.title}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                          {tpl.description}
                        </p>
                      </div>
                      <span className="text-xs font-medium text-blue-600 dark:text-blue-400">
                        Use template →
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {section === 'open' && (
              <div className="space-y-8">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    Open Document
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    Import an existing Word (.docx), HTML, or plain text (.txt) file from your
                    computer, or resume a recent draft.
                  </p>
                </div>

                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".docx,.html,.htm,.txt,.md"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        onImportFile(f);
                        onClose();
                      }
                      e.target.value = '';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-3 px-5 py-3.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 transition-colors cursor-pointer"
                  >
                    <FolderOpen className="w-5 h-5 text-blue-600" />
                    <div className="text-left">
                      <div className="text-sm font-semibold text-slate-900 dark:text-white">
                        Browse Computer (.docx, .html, .txt)
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Opens and converts document formatting directly in your browser
                      </div>
                    </div>
                  </button>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Recent Local Documents</span>
                  </div>

                  {recentDocs.length === 0 ? (
                    <div className="p-6 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                      No saved drafts yet. Documents you edit or save will appear here.
                    </div>
                  ) : (
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-100 dark:divide-slate-800">
                      {recentDocs.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center justify-between px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                        >
                          <button
                            type="button"
                            onClick={() => {
                              onOpenRecentDoc(doc);
                              onClose();
                            }}
                            className="flex items-center gap-3 text-left min-w-0 flex-1 cursor-pointer"
                          >
                            <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                            <div className="min-w-0">
                              <div className="text-sm font-medium text-slate-900 dark:text-white truncate">
                                {doc.title}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                                {doc.wordCount.toLocaleString()} words · Updated {doc.updatedAt}
                              </div>
                            </div>
                          </button>

                          <button
                            type="button"
                            onClick={() => onDeleteRecentDoc(doc.id)}
                            title="Remove from recent"
                            className="p-1.5 rounded text-slate-400 hover:text-rose-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {section === 'export' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    Save As &amp; Print
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    Save your work in standard Microsoft Word (.docx) format for effortless sharing
                    or output a print-ready PDF.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      onExportDocx();
                      onClose();
                    }}
                    className="p-5 rounded-lg bg-white dark:bg-slate-900 border-2 border-blue-600 text-left hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition-colors cursor-pointer space-y-2"
                  >
                    <div className="flex items-center gap-2.5 text-blue-700 dark:text-blue-400 font-semibold">
                      <FileText className="w-5 h-5" />
                      <span>Word Document (.docx)</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Industry-standard OOXML file preserving headings, fonts, colors, tables,
                      lists, and exact page margins.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      setTimeout(() => onPrint(), 150);
                    }}
                    className="p-5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 text-left transition-colors cursor-pointer space-y-2"
                  >
                    <div className="flex items-center gap-2.5 text-slate-900 dark:text-white font-semibold">
                      <Printer className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                      <span>Print / Save as PDF</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Opens your system print dialog with clean page margins and zero toolbar
                      chrome for crisp paper or PDF output.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onExportHtml();
                      onClose();
                    }}
                    className="p-5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 text-left transition-colors cursor-pointer space-y-2"
                  >
                    <div className="flex items-center gap-2.5 text-slate-900 dark:text-white font-semibold">
                      <FileCode2 className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                      <span>Web Document (.html)</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Standalone styled HTML file ready for web publishing or email archiving.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onExportTxt();
                      onClose();
                    }}
                    className="p-5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 text-left transition-colors cursor-pointer space-y-2"
                  >
                    <div className="flex items-center gap-2.5 text-slate-900 dark:text-white font-semibold">
                      <FileText className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                      <span>Plain Text (.txt)</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Unformatted UTF-8 text file for universal compatibility across any device.
                    </p>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
