import React from 'react';
import { ListTree, X } from 'lucide-react';
import { HeadingNode, PageSettings } from '../types/document';

interface OutlineSidebarProps {
  headings: HeadingNode[];
  settings: PageSettings;
  onJumpToHeading: (index: number) => void;
  onClose: () => void;
}

export const OutlineSidebar: React.FC<OutlineSidebarProps> = ({
  headings,
  settings,
  onJumpToHeading,
  onClose,
}) => {
  return (
    <aside className="no-print w-60 shrink-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
      <div className="h-10 px-3 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 dark:text-slate-100">
          <ListTree className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span>Document Outline</span>
        </div>
        <button
          type="button"
          onClick={onClose}
          title="Close Outline"
          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto desktop-scroll p-3">
        {headings.length === 0 ? (
          <div className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed py-4">
            Headings you format with <strong>Heading 1</strong>, <strong>Heading 2</strong>, or{' '}
            <strong>Heading 3</strong> will appear here for quick navigation across long reports.
          </div>
        ) : (
          <nav className="flex flex-col gap-0.5" aria-label="Document Headings">
            {headings.map((h) => (
              <button
                key={h.id}
                type="button"
                onClick={() => onJumpToHeading(h.elementIndex)}
                className={`text-left text-xs py-1.5 px-2 rounded truncate transition-colors cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 ${
                  h.level === 1
                    ? 'font-semibold'
                    : h.level === 2
                    ? 'pl-4 font-medium text-slate-600 dark:text-slate-300'
                    : 'pl-6 text-slate-500 dark:text-slate-400'
                }`}
                title={h.text}
              >
                {h.text}
              </button>
            ))}
          </nav>
        )}
      </div>

      <div className="p-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
        <div className="font-medium text-slate-700 dark:text-slate-300">Page Setup</div>
        <div className="tabular-nums">
          {settings.paperSize.toUpperCase()} · {settings.orientation} · {settings.columns}{' '}
          {settings.columns === 1 ? 'col' : 'cols'}
        </div>
        <div className="font-mono tabular-nums text-[10px]">
          Margins: {settings.margins.top}&quot; T · {settings.margins.left}&quot; L ·{' '}
          {settings.margins.right}&quot; R
        </div>
      </div>
    </aside>
  );
};
