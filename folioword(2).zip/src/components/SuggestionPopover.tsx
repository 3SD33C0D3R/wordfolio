import React from 'react';
import { BookMarked, Check, EyeOff, X } from 'lucide-react';
import { ProofingIssue } from '../types/document';

interface SuggestionPopoverProps {
  issue: ProofingIssue;
  position: { x: number; y: number };
  onApply: (issue: ProofingIssue, replacement: string) => void;
  onIgnore: (issue: ProofingIssue) => void;
  onAddToDictionary: (word: string) => void;
  onClose: () => void;
}

export const SuggestionPopover: React.FC<SuggestionPopoverProps> = ({
  issue,
  position,
  onApply,
  onIgnore,
  onAddToDictionary,
  onClose,
}) => {
  return (
    <div
      className="no-print fixed z-50 w-64 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl p-3 text-left"
      style={{
        left: `${Math.min(window.innerWidth - 272, Math.max(12, position.x))}px`,
        top: `${Math.min(window.innerHeight - 220, Math.max(12, position.y))}px`,
      }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div>
          <span
            className={`text-[11px] font-semibold ${
              issue.kind === 'spelling'
                ? 'text-red-600 dark:text-red-400'
                : issue.kind === 'grammar'
                ? 'text-blue-600 dark:text-blue-400'
                : 'text-amber-600 dark:text-amber-400'
            }`}
          >
            {issue.message}
          </span>
          <div className="text-xs font-semibold text-slate-900 dark:text-white mt-0.5">
            “{issue.wordOrPhrase}”
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-0.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
          aria-label="Close suggestion popover"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug mb-2.5">
        {issue.explanation}
      </p>

      {issue.replacements.length > 0 ? (
        <div className="flex flex-col gap-1 mb-2">
          {issue.replacements.map((rep) => (
            <button
              key={rep}
              type="button"
              onClick={() => onApply(issue, rep)}
              className="flex items-center justify-between w-full px-2.5 py-1.5 rounded text-xs font-medium bg-blue-50 hover:bg-blue-600 text-blue-800 hover:text-white dark:bg-blue-950/60 dark:text-blue-200 dark:hover:bg-blue-600 transition-colors cursor-pointer"
            >
              <span>{rep === ' ' ? 'Replace with single space' : rep}</span>
              <Check className="w-3.5 h-3.5" />
            </button>
          ))}
        </div>
      ) : (
        <div className="text-[11px] italic text-slate-400 mb-2">
          No automated suggestions available.
        </div>
      )}

      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700 text-[11px]">
        <button
          type="button"
          onClick={() => onIgnore(issue)}
          className="flex items-center gap-1 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white cursor-pointer"
        >
          <EyeOff className="w-3 h-3" />
          <span>Ignore</span>
        </button>

        {issue.kind === 'spelling' && (
          <button
            type="button"
            onClick={() => onAddToDictionary(issue.wordOrPhrase)}
            className="flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
          >
            <BookMarked className="w-3 h-3" />
            <span>Add to dictionary</span>
          </button>
        )}
      </div>
    </div>
  );
};
