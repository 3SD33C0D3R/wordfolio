import React, { useState } from 'react';
import {
  Download,
  FileText,
  Moon,
  Printer,
  Redo2,
  Save,
  Sun,
  Undo2,
} from 'lucide-react';

interface TitleBarProps {
  title: string;
  onTitleChange: (title: string) => void;
  isDirty: boolean;
  lastSavedText: string;
  darkWorkspace: boolean;
  onToggleDarkWorkspace: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onSaveLocal: () => void;
  onExportDocx: () => void;
  onPrint: () => void;
  onOpenBackstage: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  title,
  onTitleChange,
  isDirty,
  lastSavedText,
  darkWorkspace,
  onToggleDarkWorkspace,
  onUndo,
  onRedo,
  onSaveLocal,
  onExportDocx,
  onPrint,
  onOpenBackstage,
}) => {
  const [editingTitle, setEditingTitle] = useState(false);

  return (
    <header className="no-print h-11 px-3 flex items-center justify-between gap-4 bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 border-b border-slate-200 dark:border-slate-800 select-none shrink-0">
      {/* Left: Brand + Quick Access Toolbar */}
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={onOpenBackstage}
          title="Open File Menu"
          className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <span className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-white shadow-2xs">
            <FileText className="w-3.5 h-3.5" />
          </span>
          <span className="text-sm font-semibold tracking-tight text-slate-900 dark:text-white">
            FolioWord
          </span>
        </button>

        <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1" aria-hidden="true" />

        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={onSaveLocal}
            title="Save Document (Ctrl+S)"
            aria-label="Save Document"
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onUndo}
            title="Undo (Ctrl+Z)"
            aria-label="Undo"
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onRedo}
            title="Redo (Ctrl+Y)"
            aria-label="Redo"
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onPrint}
            title="Print or Save as PDF (Ctrl+P)"
            aria-label="Print"
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center: Inline Document Name & Save State */}
      <div className="flex items-center gap-2 min-w-0 max-w-md flex-1 justify-center">
        {editingTitle ? (
          <input
            type="text"
            value={title}
            autoFocus
            onChange={(e) => onTitleChange(e.target.value)}
            onBlur={() => setEditingTitle(false)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === 'Escape') setEditingTitle(false);
            }}
            className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-medium px-2.5 py-1 rounded border border-blue-500 outline-none w-56 text-center"
            aria-label="Document Title"
          />
        ) : (
          <button
            type="button"
            onClick={() => setEditingTitle(true)}
            title="Click to rename document"
            className="text-xs font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 px-2.5 py-1 rounded truncate max-w-xs cursor-text transition-colors"
          >
            {title || 'Untitled Document'}
          </button>
        )}
        <span className="hidden md:inline text-[11px] text-slate-500 dark:text-slate-400 whitespace-nowrap shrink-0">
          · {isDirty ? 'Unsaved edits' : lastSavedText}
        </span>
      </div>

      {/* Right: Workspace Theme & Primary Export */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onToggleDarkWorkspace}
          title={darkWorkspace ? 'Switch to Light Workspace' : 'Switch to Dark Workspace'}
          aria-label={darkWorkspace ? 'Switch to Light Workspace' : 'Switch to Dark Workspace'}
          className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          {darkWorkspace ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <button
          type="button"
          onClick={onExportDocx}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Save .docx</span>
        </button>
      </div>
    </header>
  );
};
