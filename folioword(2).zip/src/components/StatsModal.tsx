import React from 'react';
import { X } from 'lucide-react';
import { DocumentStats } from '../types/document';

interface StatsModalProps {
  stats: DocumentStats;
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({ stats, onClose }) => {
  const rows = [
    { label: 'Words', value: stats.words.toLocaleString() },
    { label: 'Characters (with spaces)', value: stats.characters.toLocaleString() },
    { label: 'Characters (no spaces)', value: stats.charactersNoSpaces.toLocaleString() },
    { label: 'Sentences', value: stats.sentences.toLocaleString() },
    { label: 'Paragraphs', value: stats.paragraphs.toLocaleString() },
    { label: 'Estimated Pages', value: stats.estimatedPages.toLocaleString() },
    {
      label: 'Estimated Reading Time',
      value: stats.readingTimeMinutes === 0 ? '0 min' : `${stats.readingTimeMinutes} min`,
    },
    {
      label: 'Flesch-Kincaid Grade Level',
      value: stats.words > 5 ? `Grade ${stats.gradeLevel}` : 'N/A',
    },
  ];

  return (
    <div
      className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 py-3 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
            Word Count &amp; Readability
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((row) => (
            <div
              key={row.label}
              className="px-4 py-2.5 flex items-center justify-between text-xs"
            >
              <span className="text-slate-600 dark:text-slate-300">{row.label}</span>
              <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-white">
                {row.value}
              </span>
            </div>
          ))}
        </div>

        <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
