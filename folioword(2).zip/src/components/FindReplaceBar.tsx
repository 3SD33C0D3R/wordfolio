import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Replace, Search, X } from 'lucide-react';

interface FindReplaceBarProps {
  onFindNext: (query: string, matchCase: boolean) => number;
  onReplaceOne: (query: string, replacement: string, matchCase: boolean) => void;
  onReplaceAll: (query: string, replacement: string, matchCase: boolean) => number;
  onClose: () => void;
}

export const FindReplaceBar: React.FC<FindReplaceBarProps> = ({
  onFindNext,
  onReplaceOne,
  onReplaceAll,
  onClose,
}) => {
  const [query, setQuery] = useState('');
  const [replacement, setReplacement] = useState('');
  const [matchCase, setMatchCase] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  const handleFind = () => {
    if (!query) return;
    const count = onFindNext(query, matchCase);
    setStatusMessage(count === 0 ? 'No matches' : `${count} found`);
  };

  const handleReplaceAll = () => {
    if (!query) return;
    const replaced = onReplaceAll(query, replacement, matchCase);
    setStatusMessage(
      replaced === 0 ? 'No matches' : `Replaced ${replaced} ${replaced === 1 ? 'match' : 'matches'}`
    );
  };

  return (
    <div className="no-print fixed top-28 right-6 z-40 w-80 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-lg p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-100">
          <Search className="w-3.5 h-3.5 text-blue-600" />
          <span>Find &amp; Replace</span>
        </div>
        <div className="flex items-center gap-2">
          {statusMessage && (
            <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
              {statusMessage}
            </span>
          )}
          <button
            type="button"
            onClick={onClose}
            className="p-0.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
            aria-label="Close Find & Replace"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setStatusMessage('');
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleFind();
            if (e.key === 'Escape') onClose();
          }}
          placeholder="Find text..."
          autoFocus
          className="flex-1 px-2.5 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
        />
        <button
          type="button"
          onClick={handleFind}
          title="Find Next"
          className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer"
        >
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={handleFind}
          title="Find"
          className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex items-center gap-1.5">
        <input
          type="text"
          value={replacement}
          onChange={(e) => setReplacement(e.target.value)}
          placeholder="Replace with..."
          className="flex-1 px-2.5 py-1.5 text-xs rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
        />
        <button
          type="button"
          onClick={() => onReplaceOne(query, replacement, matchCase)}
          title="Replace Next"
          className="px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-medium text-slate-700 dark:text-slate-200 cursor-pointer whitespace-nowrap"
        >
          Replace
        </button>
        <button
          type="button"
          onClick={handleReplaceAll}
          title="Replace All"
          className="flex items-center gap-1 px-2 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-[11px] font-medium text-white cursor-pointer whitespace-nowrap"
        >
          <Replace className="w-3 h-3" />
          <span>All</span>
        </button>
      </div>

      <label className="flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
        <input
          type="checkbox"
          checked={matchCase}
          onChange={(e) => setMatchCase(e.target.checked)}
          className="accent-blue-600"
        />
        <span>Match exact case</span>
      </label>
    </div>
  );
};
