import React from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { DocumentStats, ProofingIssue } from '../types/document';

interface StatusBarProps {
  stats: DocumentStats;
  issues: ProofingIssue[];
  autoProofing: boolean;
  zoom: number;
  focusMode: boolean;
  onZoomChange: (zoom: number) => void;
  onToggleFocusMode: () => void;
  onOpenProofing: () => void;
  onOpenStatsModal: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  stats,
  issues,
  autoProofing,
  zoom,
  focusMode,
  onZoomChange,
  onToggleFocusMode,
  onOpenProofing,
  onOpenStatsModal,
}) => {
  const spellingCount = issues.filter((i) => i.kind === 'spelling').length;
  const grammarCount = issues.filter((i) => i.kind !== 'spelling').length;

  return (
    <footer className="no-print h-8 px-4 flex items-center justify-between gap-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 select-none shrink-0">
      {/* Left: Page, Words, Proofing status (clean unboxed text with subtle separators) */}
      <div className="flex items-center gap-3 min-w-0 overflow-hidden">
        <span className="tabular-nums whitespace-nowrap shrink-0">
          Page 1 of {stats.estimatedPages}
        </span>

        <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
          ·
        </span>

        <button
          type="button"
          onClick={onOpenStatsModal}
          title="View detailed word count & readability metrics"
          className="hover:text-slate-900 dark:hover:text-white transition-colors tabular-nums cursor-pointer whitespace-nowrap shrink-0"
        >
          {stats.words.toLocaleString()} {stats.words === 1 ? 'word' : 'words'}
        </button>

        <span className="hidden md:inline text-slate-300 dark:text-slate-700" aria-hidden="true">
          ·
        </span>

        <span className="hidden md:inline tabular-nums whitespace-nowrap shrink-0 text-slate-500 dark:text-slate-400">
          {stats.characters.toLocaleString()} chars
        </span>

        <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
          ·
        </span>

        <button
          type="button"
          onClick={onOpenProofing}
          className="flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          {!autoProofing ? (
            <span className="text-slate-400">Proofing paused</span>
          ) : issues.length === 0 ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>No proofing issues</span>
            </>
          ) : (
            <>
              <AlertCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span className="tabular-nums">
                {spellingCount > 0 && `${spellingCount} spelling`}
                {spellingCount > 0 && grammarCount > 0 && ', '}
                {grammarCount > 0 && `${grammarCount} grammar`}
              </span>
            </>
          )}
        </button>
      </div>

      {/* Right: Focus Mode & Zoom Slider */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onToggleFocusMode}
          title={focusMode ? 'Exit Focus Mode' : 'Enter Focus Mode (hide ribbon & panels)'}
          className="flex items-center gap-1 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          {focusMode ? (
            <>
              <Minimize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Exit Focus</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Focus</span>
            </>
          )}
        </button>

        <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
          |
        </span>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => onZoomChange(Math.max(50, zoom - 10))}
            title="Zoom Out"
            className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>

          <input
            type="range"
            min={50}
            max={200}
            step={5}
            value={zoom}
            onChange={(e) => onZoomChange(Number(e.target.value))}
            aria-label="Document zoom percentage"
            className="w-20 accent-blue-600 cursor-pointer"
          />

          <button
            type="button"
            onClick={() => onZoomChange(Math.min(200, zoom + 10))}
            title="Zoom In"
            className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => onZoomChange(100)}
            title="Reset zoom to 100%"
            className="w-10 text-right font-mono tabular-nums text-[11px] hover:text-slate-900 dark:hover:text-white cursor-pointer"
          >
            {zoom}%
          </button>
        </div>
      </div>
    </footer>
  );
};
