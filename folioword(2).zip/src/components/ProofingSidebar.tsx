import React, { useState } from 'react';
import {
  AlertTriangle,
  BookMarked,
  Check,
  CheckCircle2,
  MessageSquare,
  SpellCheck2,
  Trash2,
  X,
} from 'lucide-react';
import { DocumentComment, IssueKind, ProofingIssue } from '../types/document';

interface ProofingSidebarProps {
  issues: ProofingIssue[];
  comments: DocumentComment[];
  autoProofing: boolean;
  onApplyReplacement: (issue: ProofingIssue, replacement: string) => void;
  onIgnoreIssue: (issue: ProofingIssue) => void;
  onAddToDictionary: (word: string) => void;
  onSelectIssue: (issue: ProofingIssue) => void;
  onResolveComment: (id: string) => void;
  onDeleteComment: (id: string) => void;
  onClose: () => void;
}

export const ProofingSidebar: React.FC<ProofingSidebarProps> = ({
  issues,
  comments,
  autoProofing,
  onApplyReplacement,
  onIgnoreIssue,
  onAddToDictionary,
  onSelectIssue,
  onResolveComment,
  onDeleteComment,
  onClose,
}) => {
  const [tab, setTab] = useState<'proofing' | 'comments'>('proofing');
  const [filterKind, setFilterKind] = useState<'all' | IssueKind>('all');

  const filteredIssues =
    filterKind === 'all' ? issues : issues.filter((i) => i.kind === filterKind);

  const spellingCount = issues.filter((i) => i.kind === 'spelling').length;
  const grammarCount = issues.filter((i) => i.kind === 'grammar').length;
  const styleCount = issues.filter((i) => i.kind === 'style').length;

  return (
    <aside className="no-print w-80 shrink-0 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="h-10 px-3 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setTab('proofing')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              tab === 'proofing'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Proofing ({issues.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('comments')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              tab === 'comments'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Comments ({comments.filter((c) => !c.resolved).length})
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          title="Close Review Pane"
          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {tab === 'proofing' ? (
        <>
          {/* Filter Segmented Control */}
          <div className="p-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900">
            <div className="grid grid-cols-4 gap-1 p-0.5 rounded-md bg-slate-200/70 dark:bg-slate-800 text-[11px]">
              {(
                [
                  { id: 'all', label: `All (${issues.length})` },
                  { id: 'spelling', label: `Spell (${spellingCount})` },
                  { id: 'grammar', label: `Gram (${grammarCount})` },
                  { id: 'style', label: `Style (${styleCount})` },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFilterKind(f.id)}
                  className={`py-1 rounded font-medium tabular-nums transition-colors cursor-pointer truncate ${
                    filterKind === f.id
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Issue List */}
          <div className="flex-1 overflow-y-auto desktop-scroll divide-y divide-slate-100 dark:divide-slate-800">
            {!autoProofing ? (
              <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                Real-time proofing is currently paused. Enable <strong>Check As You Type</strong> in
                the Review tab to inspect your document.
              </div>
            ) : filteredIssues.length === 0 ? (
              <div className="p-6 text-center space-y-2">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 dark:text-emerald-400 mx-auto" />
                <div className="text-sm font-medium text-slate-800 dark:text-slate-100">
                  Everything looks clean
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  No spelling, grammar, or clarity issues detected in this view.
                </p>
              </div>
            ) : (
              filteredIssues.map((issue) => (
                <div
                  key={issue.id}
                  className="p-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onSelectIssue(issue)}
                      className="text-left group cursor-pointer min-w-0"
                    >
                      <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                        {issue.kind === 'spelling' ? (
                          <>
                            <SpellCheck2 className="w-3.5 h-3.5 text-red-600 shrink-0" />
                            <span className="text-red-700 dark:text-red-400">{issue.message}</span>
                          </>
                        ) : issue.kind === 'grammar' ? (
                          <>
                            <AlertTriangle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                            <span className="text-blue-700 dark:text-blue-400">{issue.message}</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            <span className="text-amber-700 dark:text-amber-400">{issue.message}</span>
                          </>
                        )}
                      </div>
                      <div className="mt-1 text-sm font-semibold text-slate-900 dark:text-white group-hover:underline truncate">
                        “{issue.wordOrPhrase}”
                      </div>
                    </button>

                    <div className="flex items-center gap-1 shrink-0">
                      {issue.kind === 'spelling' && (
                        <button
                          type="button"
                          onClick={() => onAddToDictionary(issue.wordOrPhrase)}
                          title="Add to custom dictionary"
                          className="p-1 rounded text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50 cursor-pointer"
                        >
                          <BookMarked className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onIgnoreIssue(issue)}
                        title="Ignore"
                        className="px-1.5 py-0.5 rounded text-[11px] text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-700 cursor-pointer"
                      >
                        Ignore
                      </button>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                    {issue.explanation}
                  </p>

                  {issue.replacements.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {issue.replacements.map((rep) => (
                        <button
                          key={rep}
                          type="button"
                          onClick={() => onApplyReplacement(issue, rep)}
                          className="px-2 py-1 rounded text-xs font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer"
                        >
                          {rep === ' ' ? 'Single space' : rep}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </>
      ) : (
        <div className="flex-1 overflow-y-auto desktop-scroll divide-y divide-slate-100 dark:divide-slate-800">
          {comments.length === 0 ? (
            <div className="p-6 text-center space-y-2">
              <MessageSquare className="w-7 h-7 text-slate-400 mx-auto" />
              <div className="text-sm font-medium text-slate-800 dark:text-slate-100">
                No comments yet
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Highlight text in your document and click <strong>New Comment</strong> in the Review
                tab to leave editorial notes.
              </p>
            </div>
          ) : (
            comments.map((comment) => (
              <div
                key={comment.id}
                className={`p-3 space-y-1.5 ${comment.resolved ? 'opacity-60' : ''}`}
              >
                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span className="font-semibold text-slate-700 dark:text-slate-200">
                    {comment.author}
                  </span>
                  <span>{comment.createdAt}</span>
                </div>
                {comment.quotedText && (
                  <div className="text-[11px] italic text-slate-500 dark:text-slate-400 truncate bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded">
                    “{comment.quotedText}”
                  </div>
                )}
                <p className="text-xs text-slate-800 dark:text-slate-100 leading-relaxed">
                  {comment.body}
                </p>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => onResolveComment(comment.id)}
                    className="flex items-center gap-1 text-[11px] text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
                  >
                    <Check className="w-3 h-3" />
                    <span>{comment.resolved ? 'Reopen' : 'Resolve'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteComment(comment.id)}
                    className="flex items-center gap-1 text-[11px] text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </aside>
  );
};
