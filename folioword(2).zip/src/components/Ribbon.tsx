import React, { useEffect, useRef, useState } from 'react';
import {
  AlignCenter,
  AlignJustify,
  AlignLeft,
  AlignRight,
  Bold,
  Calendar,
  ChevronDown,
  ChevronUp,
  Clipboard,
  Columns3,
  Copy,
  Eraser,
  FileSpreadsheet,
  Highlighter,
  Image as ImageIcon,
  IndentDecrease,
  IndentIncrease,
  Italic,
  Link2,
  List,
  ListOrdered,
  MessageSquarePlus,
  Minus,
  Moon,
  PanelLeft,
  PanelRight,
  Quote,
  Ruler,
  Scissors,
  Search,
  SeparatorHorizontal,
  SpellCheck2,
  Strikethrough,
  Subscript,
  Superscript,
  Table as TableIcon,
  Underline,
} from 'lucide-react';
import {
  Orientation,
  PageMargins,
  PageSettings,
  PageTone,
  PaperSize,
  RibbonTab,
} from '../types/document';

export interface ActiveFormatState {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
  subscript: boolean;
  superscript: boolean;
  align: 'left' | 'center' | 'right' | 'justify';
  unorderedList: boolean;
  orderedList: boolean;
  blockTag: string;
  fontFamily: string;
  fontSizePx: number;
  insideTable: boolean;
}

interface RibbonProps {
  activeTab: RibbonTab;
  onTabChange: (tab: RibbonTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  formatState: ActiveFormatState;
  settings: PageSettings;
  autoProofing: boolean;
  checkSpelling: boolean;
  checkGrammar: boolean;
  checkStyle: boolean;
  showOutline: boolean;
  showProofing: boolean;
  showFindReplace: boolean;
  darkWorkspace: boolean;
  issueCount: number;
  zoom: number;
  onExecCommand: (cmd: string, value?: string) => void;
  onApplyFontFamily: (font: string) => void;
  onApplyFontSizePt: (pt: number) => void;
  onApplyBlockStyle: (tag: 'P' | 'H1' | 'H2' | 'H3' | 'BLOCKQUOTE') => void;
  onClearFormatting: () => void;
  onInsertTable: (rows: number, cols: number) => void;
  onTableAction: (action: 'addRow' | 'addCol' | 'delRow' | 'delCol' | 'delTable') => void;
  onInsertImageFile: (file: File) => void;
  onInsertImageUrl: (url: string) => void;
  onInsertLink: (url: string, label?: string) => void;
  onInsertPageBreak: () => void;
  onInsertHorizontalRule: () => void;
  onInsertCurrentDate: () => void;
  onUpdateSettings: (patch: Partial<PageSettings>) => void;
  onSetMargins: (margins: PageMargins) => void;
  onToggleAutoProofing: () => void;
  onToggleCheckSpelling: () => void;
  onToggleCheckGrammar: () => void;
  onToggleCheckStyle: () => void;
  onToggleOutline: () => void;
  onToggleProofing: () => void;
  onToggleFindReplace: () => void;
  onToggleDarkWorkspace: () => void;
  onAddComment: () => void;
  onOpenStatsModal: () => void;
  onZoomChange: (zoom: number) => void;
  onToggleFocusMode: () => void;
  onOpenBackstage: () => void;
  onClipboardAction: (action: 'cut' | 'copy' | 'paste') => void;
}

type PopoverKind = 'textColor' | 'highlight' | 'table' | 'link' | 'imageUrl' | 'margins';

const FONT_OPTIONS = [
  { label: 'Source Serif 4', value: 'Source Serif 4, Georgia, serif' },
  { label: 'Plus Jakarta Sans', value: 'Plus Jakarta Sans, Arial, sans-serif' },
  { label: 'Lora', value: 'Lora, Georgia, serif' },
  { label: 'Merriweather', value: 'Merriweather, Georgia, serif' },
  { label: 'DM Sans', value: 'DM Sans, Arial, sans-serif' },
  { label: 'Playfair Display', value: 'Playfair Display, Georgia, serif' },
  { label: 'Georgia', value: 'Georgia, serif' },
  { label: 'Times New Roman', value: '"Times New Roman", Times, serif' },
  { label: 'Arial', value: 'Arial, Helvetica, sans-serif' },
  { label: 'Calibri', value: 'Calibri, Plus Jakarta Sans, sans-serif' },
  { label: 'JetBrains Mono', value: '"JetBrains Mono", monospace' },
];

const FONT_SIZES = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 24, 28, 36, 48, 72];

const TEXT_COLORS = [
  '#111827', '#374151', '#64748B', '#1D4ED8',
  '#0369A1', '#047857', '#B45309', '#DC2626',
  '#7C3AED', '#BE185D',
];

const HIGHLIGHT_COLORS = [
  { label: 'Yellow', value: '#FEF08A' },
  { label: 'Mint', value: '#BBF7D0' },
  { label: 'Sky', value: '#BAE6FD' },
  { label: 'Rose', value: '#FECACA' },
  { label: 'None', value: 'transparent' },
];

export const Ribbon: React.FC<RibbonProps> = ({
  activeTab,
  onTabChange,
  collapsed,
  onToggleCollapse,
  formatState,
  settings,
  autoProofing,
  checkSpelling,
  checkGrammar,
  checkStyle,
  showOutline,
  showProofing,
  showFindReplace,
  darkWorkspace,
  issueCount,
  zoom,
  onExecCommand,
  onApplyFontFamily,
  onApplyFontSizePt,
  onApplyBlockStyle,
  onClearFormatting,
  onInsertTable,
  onTableAction,
  onInsertImageFile,
  onInsertImageUrl,
  onInsertLink,
  onInsertPageBreak,
  onInsertHorizontalRule,
  onInsertCurrentDate,
  onUpdateSettings,
  onSetMargins,
  onToggleAutoProofing,
  onToggleCheckSpelling,
  onToggleCheckGrammar,
  onToggleCheckStyle,
  onToggleOutline,
  onToggleProofing,
  onToggleFindReplace,
  onToggleDarkWorkspace,
  onAddComment,
  onOpenStatsModal,
  onZoomChange,
  onToggleFocusMode,
  onOpenBackstage,
  onClipboardAction,
}) => {
  const [openMenu, setOpenMenu] = useState<{
    kind: PopoverKind;
    x: number;
    y: number;
  } | null>(null);
  const [tableHover, setTableHover] = useState<{ r: number; c: number }>({ r: 3, c: 3 });
  const [linkUrl, setLinkUrl] = useState('https://');
  const [linkLabel, setLinkLabel] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const imageInputRef = useRef<HTMLInputElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  // Close open ribbon popover on outside click or Escape
  useEffect(() => {
    if (!openMenu) return;

    const handleMouseDown = (e: MouseEvent) => {
      if (popoverRef.current && popoverRef.current.contains(e.target as Node)) {
        return;
      }
      setOpenMenu(null);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpenMenu(null);
    };

    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [openMenu]);

  const togglePopover = (kind: PopoverKind, e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (openMenu?.kind === kind) {
      setOpenMenu(null);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    setOpenMenu({
      kind,
      x: Math.min(window.innerWidth - 270, Math.max(12, rect.left)),
      y: rect.bottom + 6,
    });
  };

  const keepFocus = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  const iconBtn = (active: boolean) =>
    `p-1.5 rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
      active
        ? 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800'
        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent'
    }`;

  const labeledBtn = (active = false) =>
    `flex flex-col items-center justify-center gap-1 px-2.5 py-1.5 rounded text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
      active
        ? 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800'
        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent'
    }`;

  const currentPt =
    Math.round(formatState.fontSizePx * 0.75 * 2) / 2 || settings.defaultFontSizePt;

  const tabs: Array<{ id: RibbonTab; label: string }> = [
    { id: 'home', label: 'Home' },
    { id: 'insert', label: 'Insert' },
    { id: 'layout', label: 'Layout' },
    { id: 'review', label: 'Review' },
    { id: 'view', label: 'View' },
  ];

  return (
    <div className="no-print bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 select-none shrink-0 relative z-30">
      {/* Ribbon Tab Bar */}
      <div className="h-9 px-3 pt-1 flex items-end justify-between border-b border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950">
        <div className="flex items-end gap-1 h-full">
          <button
            type="button"
            onClick={() => {
              setOpenMenu(null);
              onOpenBackstage();
            }}
            className="px-3.5 h-7 mb-0.5 mr-1 rounded-md text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 flex items-center"
          >
            File
          </button>

          {tabs.map((tab) => {
            const isActive = activeTab === tab.id && !collapsed;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  if (collapsed) onToggleCollapse();
                  onTabChange(tab.id);
                  setOpenMenu(null);
                }}
                className={`px-3.5 h-8 text-xs font-medium rounded-t-md transition-colors cursor-pointer whitespace-nowrap shrink-0 flex items-center relative ${
                  isActive
                    ? 'text-blue-700 dark:text-blue-300 bg-white dark:bg-slate-900 border-x border-t border-slate-200 dark:border-slate-800 top-px'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800/80 mb-0.5 rounded-md h-7'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-1.5 mb-1">
          <button
            type="button"
            onClick={onToggleFindReplace}
            title="Find and Replace (Ctrl+F)"
            className={`hidden sm:flex items-center gap-1.5 px-2.5 h-7 rounded-md text-xs transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              showFindReplace
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Find &amp; Replace</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setOpenMenu(null);
              onToggleCollapse();
            }}
            title={collapsed ? 'Expand Ribbon' : 'Collapse Ribbon'}
            aria-label={collapsed ? 'Expand Ribbon' : 'Collapse Ribbon'}
            className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
          >
            {collapsed ? (
              <ChevronDown className="w-3.5 h-3.5" />
            ) : (
              <ChevronUp className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>

      {/* Ribbon Content Area (Fixed min-height prevents layout jump across tabs) */}
      {!collapsed && (
        <div className="px-3 py-2 min-h-[82px] flex items-stretch gap-3 overflow-x-auto desktop-scroll bg-white dark:bg-slate-900">
          {activeTab === 'home' && (
            <>
              {/* Group 1: Clipboard */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={() => onClipboardAction('paste')}
                    title="Paste from Clipboard"
                    className={labeledBtn()}
                  >
                    <Clipboard className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>Paste</span>
                  </button>
                  <div className="flex flex-col gap-0.5">
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onClipboardAction('cut')}
                      className="flex items-center gap-1.5 px-2 py-1 rounded text-[11px] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                    >
                      <Scissors className="w-3 h-3" />
                      <span>Cut</span>
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onClipboardAction('copy')}
                      className="flex items-center gap-1.5 px-2 py-1 rounded text-[11px] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </button>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Clipboard</span>
              </div>

              {/* Group 2: Font */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center gap-1.5">
                    <select
                      aria-label="Font family"
                      value={
                        FONT_OPTIONS.find((f) =>
                          formatState.fontFamily
                            .toLowerCase()
                            .includes(f.label.toLowerCase())
                        )?.value || settings.defaultFontFamily
                      }
                      onChange={(e) => onApplyFontFamily(e.target.value)}
                      className="h-7 px-2 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 outline-none focus:border-blue-500 w-36 cursor-pointer"
                    >
                      {FONT_OPTIONS.map((f) => (
                        <option key={f.label} value={f.value}>
                          {f.label}
                        </option>
                      ))}
                    </select>

                    <select
                      aria-label="Font size"
                      value={FONT_SIZES.includes(currentPt) ? currentPt : 11}
                      onChange={(e) => onApplyFontSizePt(Number(e.target.value))}
                      className="h-7 px-1.5 text-xs font-mono tabular-nums rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 outline-none focus:border-blue-500 w-15 cursor-pointer"
                    >
                      {FONT_SIZES.map((sz) => (
                        <option key={sz} value={sz}>
                          {sz}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onApplyFontSizePt(Math.min(72, currentPt + 1))}
                      title="Increase Font Size"
                      className="h-7 px-1.5 rounded border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      A+
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onApplyFontSizePt(Math.max(8, currentPt - 1))}
                      title="Decrease Font Size"
                      className="h-7 px-1.5 rounded border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      A-
                    </button>
                  </div>

                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('bold')}
                      title="Bold (Ctrl+B)"
                      className={iconBtn(formatState.bold)}
                    >
                      <Bold className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('italic')}
                      title="Italic (Ctrl+I)"
                      className={iconBtn(formatState.italic)}
                    >
                      <Italic className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('underline')}
                      title="Underline (Ctrl+U)"
                      className={iconBtn(formatState.underline)}
                    >
                      <Underline className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('strikeThrough')}
                      title="Strikethrough"
                      className={iconBtn(formatState.strike)}
                    >
                      <Strikethrough className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('subscript')}
                      title="Subscript"
                      className={iconBtn(formatState.subscript)}
                    >
                      <Subscript className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('superscript')}
                      title="Superscript"
                      className={iconBtn(formatState.superscript)}
                    >
                      <Superscript className="w-3.5 h-3.5" />
                    </button>

                    <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1" />

                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={(e) => togglePopover('textColor', e)}
                      title="Font Color"
                      className={`flex items-center gap-0.5 px-1.5 py-1 rounded text-xs font-bold cursor-pointer ${
                        openMenu?.kind === 'textColor'
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="border-b-2 border-blue-600 leading-none px-0.5">A</span>
                      <ChevronDown className="w-3 h-3 text-slate-400" />
                    </button>

                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={(e) => togglePopover('highlight', e)}
                      title="Text Highlight Color"
                      className={`flex items-center gap-0.5 px-1.5 py-1 rounded cursor-pointer ${
                        openMenu?.kind === 'highlight'
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Highlighter className="w-3.5 h-3.5" />
                      <ChevronDown className="w-3 h-3 text-slate-400" />
                    </button>

                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={onClearFormatting}
                      title="Clear Formatting"
                      className={iconBtn(false)}
                    >
                      <Eraser className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Font</span>
              </div>

              {/* Group 3: Paragraph */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('insertUnorderedList')}
                      title="Bulleted List"
                      className={iconBtn(formatState.unorderedList)}
                    >
                      <List className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('insertOrderedList')}
                      title="Numbered List"
                      className={iconBtn(formatState.orderedList)}
                    >
                      <ListOrdered className="w-3.5 h-3.5" />
                    </button>
                    <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1" />
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('outdent')}
                      title="Decrease Indent"
                      className={iconBtn(false)}
                    >
                      <IndentDecrease className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('indent')}
                      title="Increase Indent"
                      className={iconBtn(false)}
                    >
                      <IndentIncrease className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('justifyLeft')}
                      title="Align Left"
                      className={iconBtn(formatState.align === 'left')}
                    >
                      <AlignLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('justifyCenter')}
                      title="Align Center"
                      className={iconBtn(formatState.align === 'center')}
                    >
                      <AlignCenter className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('justifyRight')}
                      title="Align Right"
                      className={iconBtn(formatState.align === 'right')}
                    >
                      <AlignRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onMouseDown={keepFocus}
                      onClick={() => onExecCommand('justifyFull')}
                      title="Justify"
                      className={iconBtn(formatState.align === 'justify')}
                    >
                      <AlignJustify className="w-3.5 h-3.5" />
                    </button>

                    <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1" />

                    <select
                      aria-label="Line spacing"
                      value={settings.lineHeight}
                      onChange={(e) =>
                        onUpdateSettings({ lineHeight: Number(e.target.value) })
                      }
                      title="Line Spacing"
                      className="h-7 px-1.5 text-xs font-mono tabular-nums rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      <option value={1.0}>1.0×</option>
                      <option value={1.15}>1.15×</option>
                      <option value={1.45}>1.45×</option>
                      <option value={1.5}>1.5×</option>
                      <option value={2.0}>2.0×</option>
                    </select>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Paragraph</span>
              </div>

              {/* Group 4: Styles */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1.5">
                  {[
                    { tag: 'P' as const, label: 'Normal', sample: 'AaBb' },
                    { tag: 'H1' as const, label: 'Heading 1', sample: 'H1' },
                    { tag: 'H2' as const, label: 'Heading 2', sample: 'H2' },
                    { tag: 'H3' as const, label: 'Heading 3', sample: 'H3' },
                    { tag: 'BLOCKQUOTE' as const, label: 'Quote', sample: '“ ”' },
                  ].map((st) => {
                    const active = formatState.blockTag === st.tag;
                    return (
                      <button
                        key={st.tag}
                        type="button"
                        onMouseDown={keepFocus}
                        onClick={() => onApplyBlockStyle(st.tag)}
                        className={`flex flex-col items-center justify-center px-2.5 py-1 rounded border text-center transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                            : 'bg-slate-50/70 dark:bg-slate-800/70 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-slate-300 dark:hover:border-slate-600'
                        }`}
                      >
                        <span
                          className={`leading-tight ${
                            st.tag === 'H1'
                              ? 'text-sm font-bold'
                              : st.tag === 'H2'
                              ? 'text-xs font-semibold text-blue-700 dark:text-blue-400'
                              : st.tag === 'H3'
                              ? 'text-xs font-medium'
                              : st.tag === 'BLOCKQUOTE'
                              ? 'text-xs italic'
                              : 'text-xs'
                          }`}
                        >
                          {st.sample}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {st.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Styles</span>
              </div>

              {/* Group 5: Editing */}
              <div className="flex flex-col justify-between shrink-0">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={onToggleFindReplace}
                    className={labeledBtn(showFindReplace)}
                  >
                    <Search className="w-4 h-4" />
                    <span>Find</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Editing</span>
              </div>
            </>
          )}

          {activeTab === 'insert' && (
            <>
              {/* Tables */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={(e) => togglePopover('table', e)}
                    className={labeledBtn(openMenu?.kind === 'table')}
                  >
                    <TableIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>Table</span>
                  </button>

                  {formatState.insideTable && (
                    <div className="flex flex-col gap-1 pl-1">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onMouseDown={keepFocus}
                          onClick={() => onTableAction('addRow')}
                          className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[11px] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                        >
                          + Row
                        </button>
                        <button
                          type="button"
                          onMouseDown={keepFocus}
                          onClick={() => onTableAction('addCol')}
                          className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[11px] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                        >
                          + Column
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onMouseDown={keepFocus}
                          onClick={() => onTableAction('delRow')}
                          className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[11px] text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap"
                        >
                          - Row
                        </button>
                        <button
                          type="button"
                          onMouseDown={keepFocus}
                          onClick={() => onTableAction('delCol')}
                          className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[11px] text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer whitespace-nowrap"
                        >
                          - Column
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Tables</span>
              </div>

              {/* Media & Links */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1">
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) onInsertImageFile(f);
                      e.target.value = '';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => imageInputRef.current?.click()}
                    className={labeledBtn()}
                  >
                    <ImageIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Picture</span>
                  </button>

                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={(e) => togglePopover('imageUrl', e)}
                    className={labeledBtn(openMenu?.kind === 'imageUrl')}
                  >
                    <FileSpreadsheet className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <span>Image URL</span>
                  </button>

                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={(e) => togglePopover('link', e)}
                    className={labeledBtn(openMenu?.kind === 'link')}
                  >
                    <Link2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>Hyperlink</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Illustrations &amp; Links
                </span>
              </div>

              {/* Pages & Elements */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={onInsertPageBreak}
                    className={labeledBtn()}
                  >
                    <SeparatorHorizontal className="w-4 h-4" />
                    <span>Page Break</span>
                  </button>
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={onInsertHorizontalRule}
                    className={labeledBtn()}
                  >
                    <Minus className="w-4 h-4" />
                    <span>Divider Line</span>
                  </button>
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={() => onApplyBlockStyle('BLOCKQUOTE')}
                    className={labeledBtn()}
                  >
                    <Quote className="w-4 h-4" />
                    <span>Block Quote</span>
                  </button>
                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={onInsertCurrentDate}
                    className={labeledBtn()}
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Date</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Pages &amp; Text Blocks
                </span>
              </div>

              {/* Header & Footer */}
              <div className="flex flex-col justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ showHeaderFooter: !settings.showHeaderFooter })
                    }
                    className={labeledBtn(settings.showHeaderFooter)}
                  >
                    <span className="text-xs font-semibold border border-current px-1.5 py-0.5 rounded-2xs">
                      H / F
                    </span>
                    <span>Header &amp; Footer</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Header &amp; Footer
                </span>
              </div>
            </>
          )}

          {activeTab === 'layout' && (
            <>
              {/* Margins */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1.5">
                  {[
                    {
                      label: 'Normal',
                      sub: '1.0"',
                      m: { top: 1, bottom: 1, left: 1, right: 1 },
                    },
                    {
                      label: 'Narrow',
                      sub: '0.5"',
                      m: { top: 0.5, bottom: 0.5, left: 0.5, right: 0.5 },
                    },
                    {
                      label: 'Moderate',
                      sub: '0.75"',
                      m: { top: 1, bottom: 1, left: 0.75, right: 0.75 },
                    },
                    {
                      label: 'Wide',
                      sub: '1.5" LR',
                      m: { top: 1, bottom: 1, left: 1.5, right: 1.5 },
                    },
                  ].map((preset) => {
                    const isCurrent =
                      Math.abs(settings.margins.top - preset.m.top) < 0.05 &&
                      Math.abs(settings.margins.left - preset.m.left) < 0.05 &&
                      Math.abs(settings.margins.right - preset.m.right) < 0.05;
                    return (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => onSetMargins(preset.m)}
                        className={`px-2.5 py-1 rounded border text-left transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          isCurrent
                            ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                            : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        <div className="text-[11px] font-medium">{preset.label}</div>
                        <div className="text-[10px] font-mono tabular-nums text-slate-400">
                          {preset.sub}
                        </div>
                      </button>
                    );
                  })}

                  <button
                    type="button"
                    onClick={(e) => togglePopover('margins', e)}
                    className={labeledBtn(openMenu?.kind === 'margins')}
                  >
                    <span className="text-xs font-mono tabular-nums">
                      {settings.margins.left.toFixed(1)}&quot;
                    </span>
                    <span>Custom</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Margins</span>
              </div>

              {/* Page Setup */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-500">Orientation</span>
                    <div className="flex items-center gap-1">
                      {(['portrait', 'landscape'] as Orientation[]).map((ori) => (
                        <button
                          key={ori}
                          type="button"
                          onClick={() => onUpdateSettings({ orientation: ori })}
                          className={`px-2.5 py-1 rounded text-xs capitalize border cursor-pointer whitespace-nowrap ${
                            settings.orientation === ori
                              ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                              : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                          }`}
                        >
                          {ori}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-500">Paper Size</span>
                    <select
                      aria-label="Paper Size"
                      value={settings.paperSize}
                      onChange={(e) =>
                        onUpdateSettings({ paperSize: e.target.value as PaperSize })
                      }
                      className="h-7 px-2 text-xs rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 cursor-pointer"
                    >
                      <option value="letter">US Letter (8.5 × 11&quot;)</option>
                      <option value="a4">A4 (8.27 × 11.69&quot;)</option>
                      <option value="legal">Legal (8.5 × 14&quot;)</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-500">Columns</span>
                    <div className="flex items-center gap-1">
                      {([1, 2, 3] as const).map((cols) => (
                        <button
                          key={cols}
                          type="button"
                          onClick={() => onUpdateSettings({ columns: cols })}
                          className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-mono tabular-nums border cursor-pointer ${
                            settings.columns === cols
                              ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                              : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                          }`}
                        >
                          <Columns3 className="w-3 h-3" />
                          <span>{cols}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Page Setup</span>
              </div>

              {/* Spacing & Page Tone */}
              <div className="flex flex-col justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-500">Paragraph Spacing</span>
                    <select
                      aria-label="Paragraph spacing after"
                      value={settings.paragraphSpacingAfter}
                      onChange={(e) =>
                        onUpdateSettings({
                          paragraphSpacingAfter: Number(e.target.value),
                        })
                      }
                      className="h-7 px-2 text-xs font-mono tabular-nums rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 cursor-pointer"
                    >
                      <option value={0.25}>Compact (0.25em)</option>
                      <option value={0.75}>Standard (0.75em)</option>
                      <option value={1.15}>Relaxed (1.15em)</option>
                      <option value={1.5}>Wide (1.5em)</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-slate-500">Page Paper Tone</span>
                    <div className="flex items-center gap-1">
                      {(
                        [
                          { id: 'white', label: 'Crisp White' },
                          { id: 'ivory', label: 'Warm Ivory' },
                          { id: 'cool', label: 'Soft Slate' },
                        ] as Array<{ id: PageTone; label: string }>
                      ).map((tone) => (
                        <button
                          key={tone.id}
                          type="button"
                          onClick={() => onUpdateSettings({ pageTone: tone.id })}
                          className={`px-2 py-1 rounded text-xs border cursor-pointer whitespace-nowrap ${
                            settings.pageTone === tone.id
                              ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                              : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                          }`}
                        >
                          {tone.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Spacing &amp; Paper
                </span>
              </div>
            </>
          )}

          {activeTab === 'review' && (
            <>
              {/* Proofing */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onToggleProofing}
                    className={labeledBtn(showProofing)}
                  >
                    <SpellCheck2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span className="tabular-nums">Proofing Pane ({issueCount})</span>
                  </button>

                  <button
                    type="button"
                    onClick={onToggleAutoProofing}
                    className={labeledBtn(autoProofing)}
                  >
                    <span className="text-xs font-semibold">
                      {autoProofing ? 'Active' : 'Paused'}
                    </span>
                    <span>Check As You Type</span>
                  </button>

                  <div className="flex items-center gap-3 pl-2 text-xs">
                    <label className="flex items-center gap-1.5 cursor-pointer whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={checkSpelling}
                        onChange={onToggleCheckSpelling}
                        className="accent-red-600 cursor-pointer"
                      />
                      <span>Spelling</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={checkGrammar}
                        onChange={onToggleCheckGrammar}
                        className="accent-blue-600 cursor-pointer"
                      />
                      <span>Grammar</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={checkStyle}
                        onChange={onToggleCheckStyle}
                        className="accent-amber-600 cursor-pointer"
                      />
                      <span>Clarity &amp; Style</span>
                    </label>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Spelling &amp; Grammar
                </span>
              </div>

              {/* Insights & Comments */}
              <div className="flex flex-col justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onOpenStatsModal}
                    className={labeledBtn()}
                  >
                    <span className="text-xs font-mono font-semibold">123</span>
                    <span>Word Count &amp; Readability</span>
                  </button>

                  <button
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={onAddComment}
                    className={labeledBtn()}
                  >
                    <MessageSquarePlus className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span>New Comment</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Insights &amp; Annotations
                </span>
              </div>
            </>
          )}

          {activeTab === 'view' && (
            <>
              {/* Document Views */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleFocusMode}
                    className={labeledBtn(false)}
                  >
                    <span className="text-xs font-semibold">Focus</span>
                    <span>Distraction-Free</span>
                  </button>
                  <button
                    type="button"
                    onClick={onToggleDarkWorkspace}
                    className={labeledBtn(darkWorkspace)}
                  >
                    <Moon className="w-4 h-4" />
                    <span>Dark Workspace</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Views</span>
              </div>

              {/* Show / Panes */}
              <div className="flex flex-col justify-between pr-3 border-r border-slate-200 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ showRuler: !settings.showRuler })}
                    className={labeledBtn(settings.showRuler)}
                  >
                    <Ruler className="w-4 h-4" />
                    <span>Ruler</span>
                  </button>
                  <button
                    type="button"
                    onClick={onToggleOutline}
                    className={labeledBtn(showOutline)}
                  >
                    <PanelLeft className="w-4 h-4" />
                    <span>Outline Pane</span>
                  </button>
                  <button
                    type="button"
                    onClick={onToggleProofing}
                    className={labeledBtn(showProofing)}
                  >
                    <PanelRight className="w-4 h-4" />
                    <span>Review Pane</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Show</span>
              </div>

              {/* Zoom */}
              <div className="flex flex-col justify-between shrink-0">
                <div className="flex items-center gap-1">
                  {[75, 100, 125, 150].map((z) => (
                    <button
                      key={z}
                      type="button"
                      onClick={() => onZoomChange(z)}
                      className={`px-2.5 py-1.5 rounded text-xs font-mono tabular-nums border cursor-pointer ${
                        zoom === z
                          ? 'bg-blue-50 border-blue-300 text-blue-800 dark:bg-blue-950/60 dark:border-blue-700 dark:text-blue-200'
                          : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {z}%
                    </button>
                  ))}
                </div>
                <span className="text-[10px] text-slate-400 text-center mt-1">Zoom</span>
              </div>
            </>
          )}
        </div>
      )}

      {/* Fixed-positioned Popovers (never clipped by ribbon overflow) */}
      {openMenu && (
        <div
          ref={popoverRef}
          className="fixed z-50 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl"
          style={{ left: `${openMenu.x}px`, top: `${openMenu.y}px` }}
        >
          {openMenu.kind === 'textColor' && (
            <div className="p-2.5 w-44">
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                Text Color
              </div>
              <div className="grid grid-cols-5 gap-1.5 mb-2">
                {TEXT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={() => {
                      onExecCommand('foreColor', hex);
                      setOpenMenu(null);
                    }}
                    className="w-6 h-6 rounded border border-slate-200 dark:border-slate-600 cursor-pointer hover:scale-110 transition-transform"
                    style={{ backgroundColor: hex }}
                    aria-label={`Text color ${hex}`}
                  />
                ))}
              </div>
              <label className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 pt-1.5 border-t border-slate-100 dark:border-slate-700">
                <span>Custom</span>
                <input
                  type="color"
                  onChange={(e) => {
                    onExecCommand('foreColor', e.target.value);
                    setOpenMenu(null);
                  }}
                  className="w-6 h-5 cursor-pointer bg-transparent"
                />
              </label>
            </div>
          )}

          {openMenu.kind === 'highlight' && (
            <div className="p-2 w-40">
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5 px-1">
                Highlight
              </div>
              <div className="flex flex-col gap-0.5">
                {HIGHLIGHT_COLORS.map((c) => (
                  <button
                    key={c.label}
                    type="button"
                    onMouseDown={keepFocus}
                    onClick={() => {
                      onExecCommand('hiliteColor', c.value);
                      setOpenMenu(null);
                    }}
                    className="flex items-center gap-2 px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-xs text-slate-700 dark:text-slate-200 cursor-pointer"
                  >
                    <span
                      className="w-3.5 h-3.5 rounded border border-slate-300"
                      style={{
                        backgroundColor: c.value === 'transparent' ? '#ffffff' : c.value,
                      }}
                    />
                    <span>{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {openMenu.kind === 'table' && (
            <div className="p-2.5">
              <div className="text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-2 tabular-nums">
                Insert {tableHover.r} × {tableHover.c} Table
              </div>
              <div className="grid grid-cols-6 gap-1">
                {Array.from({ length: 36 }).map((_, idx) => {
                  const r = Math.floor(idx / 6) + 1;
                  const c = (idx % 6) + 1;
                  const highlighted = r <= tableHover.r && c <= tableHover.c;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onMouseDown={keepFocus}
                      onMouseEnter={() => setTableHover({ r, c })}
                      onClick={() => {
                        onInsertTable(r, c);
                        setOpenMenu(null);
                      }}
                      className={`w-4 h-4 border rounded-2xs cursor-pointer ${
                        highlighted
                          ? 'bg-blue-500/25 border-blue-600'
                          : 'bg-slate-50 dark:bg-slate-700 border-slate-300 dark:border-slate-600'
                      }`}
                      aria-label={`Insert ${r} by ${c} table`}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {openMenu.kind === 'imageUrl' && (
            <div className="p-3 w-64">
              <div className="text-xs font-medium text-slate-700 dark:text-slate-200 mb-2">
                Insert Image from URL
              </div>
              <input
                type="url"
                autoFocus
                placeholder="https://example.com/chart.png"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && imageUrl.trim()) {
                    onInsertImageUrl(imageUrl.trim());
                    setImageUrl('');
                    setOpenMenu(null);
                  }
                }}
                className="w-full px-2.5 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 mb-2 outline-none focus:border-blue-500"
              />
              <div className="flex justify-end gap-1.5">
                <button
                  type="button"
                  onClick={() => setOpenMenu(null)}
                  className="px-2.5 py-1 text-xs rounded text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (imageUrl.trim()) {
                      onInsertImageUrl(imageUrl.trim());
                      setImageUrl('');
                      setOpenMenu(null);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
                >
                  Insert
                </button>
              </div>
            </div>
          )}

          {openMenu.kind === 'link' && (
            <div className="p-3 w-64">
              <div className="text-xs font-medium text-slate-700 dark:text-slate-200 mb-2">
                Insert Hyperlink
              </div>
              <input
                type="text"
                autoFocus
                placeholder="Display text (optional)"
                value={linkLabel}
                onChange={(e) => setLinkLabel(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 mb-2 outline-none focus:border-blue-500"
              />
              <input
                type="url"
                placeholder="https://..."
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && linkUrl.trim()) {
                    onInsertLink(linkUrl.trim(), linkLabel.trim() || undefined);
                    setLinkLabel('');
                    setLinkUrl('https://');
                    setOpenMenu(null);
                  }
                }}
                className="w-full px-2.5 py-1.5 text-xs rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 mb-2 outline-none focus:border-blue-500"
              />
              <div className="flex justify-end gap-1.5">
                <button
                  type="button"
                  onClick={() => setOpenMenu(null)}
                  className="px-2.5 py-1 text-xs rounded text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (linkUrl.trim()) {
                      onInsertLink(linkUrl.trim(), linkLabel.trim() || undefined);
                      setLinkLabel('');
                      setLinkUrl('https://');
                      setOpenMenu(null);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
                >
                  Insert
                </button>
              </div>
            </div>
          )}

          {openMenu.kind === 'margins' && (
            <div className="p-3 w-56">
              <div className="text-xs font-semibold text-slate-700 dark:text-slate-200 mb-2">
                Custom Margins (inches)
              </div>
              <div className="grid grid-cols-2 gap-2">
                {(['top', 'bottom', 'left', 'right'] as const).map((side) => (
                  <label key={side} className="flex flex-col gap-0.5 text-[11px]">
                    <span className="capitalize text-slate-500 dark:text-slate-400">
                      {side}
                    </span>
                    <input
                      type="number"
                      min={0.25}
                      max={3}
                      step={0.1}
                      value={settings.margins[side]}
                      onChange={(e) => {
                        const v = Math.max(
                          0.25,
                          Math.min(3, Number(e.target.value) || 0.5)
                        );
                        onSetMargins({ ...settings.margins, [side]: v });
                      }}
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-mono tabular-nums text-xs"
                    />
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
