import React, { useRef } from 'react';

interface RulerProps {
  pageWidthPx: number;
  pageWidthInches: number;
  leftMarginIn: number;
  rightMarginIn: number;
  zoomScale: number;
  onMarginsChange: (leftIn: number, rightIn: number) => void;
}

export const Ruler: React.FC<RulerProps> = ({
  pageWidthPx,
  pageWidthInches,
  leftMarginIn,
  rightMarginIn,
  zoomScale,
  onMarginsChange,
}) => {
  const rulerRef = useRef<HTMLDivElement>(null);
  const scaledWidth = pageWidthPx * zoomScale;
  const pxPerInch = scaledWidth / pageWidthInches;
  const leftMarginPx = leftMarginIn * pxPerInch;
  const rightMarginPx = rightMarginIn * pxPerInch;

  const startDrag = (side: 'left' | 'right', e: React.MouseEvent) => {
    e.preventDefault();
    const rulerEl = rulerRef.current;
    if (!rulerEl) return;

    const handleMove = (moveEvent: MouseEvent) => {
      const rect = rulerEl.getBoundingClientRect();
      const relX = moveEvent.clientX - rect.left;
      const inches = relX / pxPerInch;

      if (side === 'left') {
        const maxLeft = pageWidthInches - rightMarginIn - 1.5;
        const clamped = Math.max(0.25, Math.min(maxLeft, Math.round(inches * 10) / 10));
        onMarginsChange(clamped, rightMarginIn);
      } else {
        const fromRightIn = pageWidthInches - inches;
        const maxRight = pageWidthInches - leftMarginIn - 1.5;
        const clamped = Math.max(0.25, Math.min(maxRight, Math.round(fromRightIn * 10) / 10));
        onMarginsChange(leftMarginIn, clamped);
      }
    };

    const handleUp = () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
    };

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
  };

  const totalTicks = Math.floor(pageWidthInches * 4);

  return (
    <div className="no-print w-full flex justify-center py-1.5 bg-slate-100/90 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 select-none shrink-0 overflow-hidden">
      <div
        ref={rulerRef}
        className="relative h-5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xs shadow-2xs"
        style={{ width: `${scaledWidth}px` }}
      >
        {/* Left margin shaded zone */}
        <div
          className="absolute inset-y-0 left-0 bg-slate-200/80 dark:bg-slate-700/70 pointer-events-none"
          style={{ width: `${leftMarginPx}px` }}
        />

        {/* Right margin shaded zone */}
        <div
          className="absolute inset-y-0 right-0 bg-slate-200/80 dark:bg-slate-700/70 pointer-events-none"
          style={{ width: `${rightMarginPx}px` }}
        />

        {/* Tick marks */}
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: totalTicks + 1 }).map((_, i) => {
            const inchPos = i / 4;
            const leftPx = inchPos * pxPerInch;
            const isWhole = i % 4 === 0;
            const isHalf = i % 2 === 0 && !isWhole;
            const labelNum = Math.round(inchPos);

            return (
              <div
                key={i}
                className="absolute bottom-0 flex flex-col items-center"
                style={{ left: `${leftPx}px`, transform: 'translateX(-50%)' }}
              >
                {isWhole && labelNum > 0 && labelNum < pageWidthInches && (
                  <span className="text-[9px] font-mono tabular-nums text-slate-500 dark:text-slate-400 leading-none mb-0.5">
                    {labelNum}
                  </span>
                )}
                <div
                  className={`w-px bg-slate-400 dark:bg-slate-500 ${
                    isWhole ? 'h-2' : isHalf ? 'h-1.5' : 'h-1'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Left margin drag handle */}
        <button
          type="button"
          onMouseDown={(e) => startDrag('left', e)}
          title={`Left Margin: ${leftMarginIn.toFixed(2)}" (drag to adjust)`}
          aria-label="Adjust left margin"
          className="absolute top-0 bottom-0 w-2.5 -ml-1.25 cursor-ew-resize group flex items-center justify-center z-10"
          style={{ left: `${leftMarginPx}px` }}
        >
          <span className="w-1.5 h-3.5 rounded-xs bg-blue-600 group-hover:bg-blue-500 shadow-xs" />
        </button>

        {/* Right margin drag handle */}
        <button
          type="button"
          onMouseDown={(e) => startDrag('right', e)}
          title={`Right Margin: ${rightMarginIn.toFixed(2)}" (drag to adjust)`}
          aria-label="Adjust right margin"
          className="absolute top-0 bottom-0 w-2.5 -mr-1.25 cursor-ew-resize group flex items-center justify-center z-10"
          style={{ right: `${rightMarginPx}px` }}
        >
          <span className="w-1.5 h-3.5 rounded-xs bg-blue-600 group-hover:bg-blue-500 shadow-xs" />
        </button>
      </div>
    </div>
  );
};
