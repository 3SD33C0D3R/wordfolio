export type RibbonTab = 'file' | 'home' | 'insert' | 'layout' | 'review' | 'view';

export type PaperSize = 'letter' | 'a4' | 'legal';
export type Orientation = 'portrait' | 'landscape';
export type PageTone = 'white' | 'ivory' | 'cool';

export interface PageMargins {
  top: number; // inches
  bottom: number; // inches
  left: number; // inches
  right: number; // inches
}

export interface PageSettings {
  paperSize: PaperSize;
  orientation: Orientation;
  margins: PageMargins;
  columns: 1 | 2 | 3;
  lineHeight: number;
  paragraphSpacingAfter: number; // em
  defaultFontFamily: string;
  defaultFontSizePt: number;
  showRuler: boolean;
  showHeaderFooter: boolean;
  headerText: string;
  footerText: string;
  pageTone: PageTone;
}

export type IssueKind = 'spelling' | 'grammar' | 'style';

export interface OverlayRect {
  left: number;
  top: number;
  width: number;
  height: number;
}

export interface ProofingIssue {
  id: string;
  kind: IssueKind;
  wordOrPhrase: string;
  contextSnippet: string;
  message: string;
  explanation: string;
  replacements: string[];
  startOffset: number;
  endOffset: number;
  range: Range;
  rects: OverlayRect[];
}

export interface DocumentStats {
  words: number;
  characters: number;
  charactersNoSpaces: number;
  sentences: number;
  paragraphs: number;
  readingTimeMinutes: number;
  gradeLevel: number;
  estimatedPages: number;
}

export interface HeadingNode {
  id: string;
  level: 1 | 2 | 3;
  text: string;
  elementIndex: number;
}

export interface DocumentComment {
  id: string;
  quotedText: string;
  body: string;
  author: string;
  createdAt: string;
  resolved: boolean;
}

export interface StoredDocument {
  id: string;
  title: string;
  html: string;
  settings: PageSettings;
  comments: DocumentComment[];
  updatedAt: string;
  wordCount: number;
}

export interface TemplatePreset {
  id: string;
  title: string;
  category: 'Blank' | 'Academic' | 'Corporate' | 'Personal';
  description: string;
  defaultTitle: string;
  html: string;
  settings: Partial<PageSettings>;
}
